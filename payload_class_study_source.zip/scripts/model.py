#!/usr/bin/env python3
"""Sizing, cost and market model for the 200 kg vs >=400 kg payload-class study.
Run from the report root:  python3 scripts/model.py
Writes figures/*.pdf and generated/*.tex, generated/model.json."""
import json, math, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG, GEN = os.path.join(ROOT, "figures"), os.path.join(ROOT, "generated")
G0 = 9.80665
USD2EUR = 0.86

C_A, C_B, C_C = "#2a78d6", "#eb6834", "#1baf7a"      # class 200 / 400 / 600
C_REF, C_EU, C_INT = "#8a8984", "#2a78d6", "#eb6834"
INK, INK2, GRID, AXIS = "#0b0b0b", "#52514e", "#e1e0d9", "#c3c2b7"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8.5, "axes.edgecolor": AXIS,
    "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
    "axes.titlesize": 9.5, "axes.titleweight": "bold", "axes.titlecolor": INK,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
    "grid.color": GRID, "grid.linewidth": 0.6, "legend.frameon": False,
    "savefig.bbox": "tight", "savefig.dpi": 300, "lines.linewidth": 2,
})

# ------------------------------------------------------------------ sizing
DV = 9600.0                 # ideal dv, 500 km SSO incl. losses (validated on Vega-C)
ISP = (300.0, 340.0)        # effective S1 / vacuum S2, LOX/hydrocarbon class
A_STR = (0.080, 0.090)      # inert mass proportional to propellant
M_FIX = (420.0, 190.0)      # size-independent inert mass per stage (avionics, harness,
                            # minimum-gauge parts, separation, engine fixed mass)
M_FAIR = 0.0                # fairing treated as part of S2 fixed mass (jettison ignored)

def stage_inert(mp, i):
    return A_STR[i] * mp + M_FIX[i]

def dv_of(mp1, mp2, pl):
    m2i = stage_inert(mp2, 1); m1i = stage_inert(mp1, 0)
    m02 = pl + m2i + mp2; mf2 = pl + m2i
    m01 = m02 + m1i + mp1; mf1 = m02 + m1i
    return ISP[0]*G0*math.log(m01/mf1) + ISP[1]*G0*math.log(m02/mf2), m01, m1i + m2i

def size(pl):
    best = None
    for f2 in np.linspace(0.10, 0.40, 121):          # S2 share of total propellant
        lo, hi = 100.0, 4e6
        for _ in range(80):
            mid = 0.5*(lo+hi)
            dv, _, _ = dv_of(mid*(1-f2), mid*f2, pl)
            lo, hi = (mid, hi) if dv < DV else (lo, mid)
        mp = hi; dv, m0, mdry = dv_of(mp*(1-f2), mp*f2, pl)
        if best is None or m0 < best["glom"]:
            best = dict(pl=pl, glom=m0, mdry=mdry, mprop=mp, f2=f2,
                        lam=pl/m0, eps_avg=mdry/(mdry+mp))
    return best

CLASSES = [("A", 200, C_A), ("B", 400, C_B), ("C", 600, C_C)]
SIZ = {c: size(p) for c, p, _ in CLASSES}
SIZ["D"] = size(1000)
curve_pl = np.array([100, 150, 200, 250, 300, 400, 500, 600, 800, 1000, 1300])
curve = [size(p) for p in curve_pl]

# ------------------------------------------------------------------ cost
# Price(N) = (1+m) * [ C_veh + C_ops + F/N ]
#   C_veh = k * Mdry^b    recurring hardware
#   C_ops = O0 * (GLOM/GLOM_A)^0.3   campaign, range, insurance-free ops
#   F     = F0 * (Mdry/Mdry_A)^0.3   fixed annual: staff, sustaining eng., sites
B_EXP, MARGIN = 0.60, 0.15
O0, F0 = 1.0e6, 35e6
ELECTRON_ASP_EUR = 8.5e6 * USD2EUR     # 2025 average revenue per launch
ELECTRON_N = 21                         # 2025 missions
refA = SIZ["A"]
# calibrate k so that class A at Electron cadence returns Electron's 2025 ASP
k = (ELECTRON_ASP_EUR/(1+MARGIN) - O0 - F0/ELECTRON_N) / refA["mdry"]**B_EXP

def costs(s, b=B_EXP, kk=None, f0=F0):
    kk = k if kk is None else kk
    kk_b = kk * refA["mdry"]**B_EXP / refA["mdry"]**b    # keep class-A cost fixed when b varies
    cveh = kk_b * s["mdry"]**b
    cops = O0 * (s["glom"]/refA["glom"])**0.3
    F = f0 * (s["mdry"]/refA["mdry"])**0.3
    return cveh, cops, F

def price(s, N, **kw):
    cveh, cops, F = costs(s, **kw)
    return (1+MARGIN)*(cveh + cops + F/N)

# market anchors (EUR)
RIDE_BASE, RIDE_KG = 350e3*USD2EUR, 7000*USD2EUR       # 50 kg block + per kg
def rideshare(m):
    return RIDE_BASE + max(0.0, m-50)*RIDE_KG

ANCH = [  # name, SSO kg, price EUR, kind ('price' observed / 'target' claim), colour
    ("Electron (2025 ASP)", 200, 8.5e6*USD2EUR, "price", C_INT),
    ("Alpha (list, PUG 5.2)", 630, 19e6*USD2EUR, "price", C_INT),
    ("Vega-C (Sentinel-1C)", 2300, 51.65e6, "price", C_EU),
    ("Spectrum (target)", 700, 10000*700, "target", C_EU),
    ("RFA One (2021 claim)", 1300, 3.0e6, "target", C_EU),
]

# ------------------------------------------------------------------ figures
def fig_market():
    sats = [("ICEYE SAR", 85), ("StriX SAR", 100), ("QPS-SAR", 100), ("VICTUS NOX sat.", 100),
            ("Pelican (launch mass)", 160), ("Pelican (Planet spec.)", 200),
            ("Mean smallsat 2023\n(excl. broadband)", 44), ("Mean smallsat 2024\n(incl. broadband)", 223)]
    fig, ax = plt.subplots(figsize=(6.6, 2.9))
    for i, (n, m) in enumerate(sats):
        col = INK2 if "Mean" in n else INK
        ax.plot([m], [i], "o", ms=7, color=col, mec="white", mew=1.5, zorder=3)
        if m > 400:
            ax.text(m-12, i, f"{n}  ({m} kg)", va="center", ha="right", fontsize=7.4, color=col)
        else:
            ax.text(m+12, i, f"{n}  ({m} kg)", va="center", fontsize=7.4, color=col)
    for c, p, colr in CLASSES:
        use = 0.85*p
        ax.axvspan(use, p, color=colr, alpha=0.10, lw=0)
        ax.axvline(p, color=colr, lw=1.6)
        ax.text(p, len(sats)-0.2, f"Class {c}\n{p} kg", color=colr, ha="center", va="bottom",
                fontsize=7.6, fontweight="bold")
    ax.set_xlim(0, 700); ax.set_ylim(-0.7, len(sats)+0.9); ax.set_yticks([])
    ax.set_xlabel("Mass (kg)  |  shaded band = last 15 % of capacity consumed by adapter, dispenser and margin")
    ax.grid(axis="y", visible=False); ax.spines["left"].set_visible(False)
    fig.savefig(os.path.join(FIG, "market_masses.pdf")); plt.close(fig)

def fig_sizing():
    pls = curve_pl; glom = [c["glom"]/1000 for c in curve]; lam = [100*c["lam"] for c in curve]
    pts = [("Electron", 200, 13.0, C_INT, (6, -9)), ("Prime", 150, 18.0, "#8a8984", (-4, 6)),
           ("Alpha", 630, 54.1, C_INT, (-6, 5)), ("MIURA 5", 540, 69.0, C_EU, (6, 0)),
           ("Spectrum (est.)", 700, 49.4, C_EU, (6, -9))]
    fig, axs = plt.subplots(1, 2, figsize=(6.8, 2.8))
    ax = axs[0]
    ax.plot(pls, glom, color=INK, lw=2, label="Model (two-stage, 500 km SSO)")
    for n, p, g, col, off in pts:
        ax.plot(p, g, "o", ms=7, color=col, mec="white", mew=1.5, zorder=3)
        ax.annotate(n, (p, g), xytext=off, textcoords="offset points", fontsize=7, color=INK2,
                    ha="right" if off[0] < 0 else "left")
    for c, p, colr in CLASSES:
        ax.axvline(p, color=colr, lw=1, ls=(0, (3, 2)))
    ax.set_xlabel("SSO payload (kg)"); ax.set_ylabel("Lift-off mass (t)"); ax.set_title("Lift-off mass")
    ax.set_xlim(80, 1350); ax.set_ylim(0, 80); ax.legend(loc="upper left", fontsize=7)
    ax = axs[1]
    ax.plot(pls, lam, color=INK, lw=2)
    for c, p, colr in CLASSES:
        s = SIZ[c]; ax.plot(p, 100*s["lam"], "o", ms=7, color=colr, mec="white", mew=1.5, zorder=3)
        ax.annotate(f"{c}: {100*s['lam']:.2f} %", (p, 100*s["lam"]), xytext=(6, -11),
                    textcoords="offset points", fontsize=7.2, color=INK)
    ax.set_xlabel("SSO payload (kg)"); ax.set_ylabel("Payload fraction (%)"); ax.set_title("Payload fraction")
    ax.set_xlim(80, 1350)
    fig.tight_layout(w_pad=2.5); fig.savefig(os.path.join(FIG, "sizing.pdf")); plt.close(fig)

NS = np.arange(2, 31)
def fig_price_cadence():
    fig, ax = plt.subplots(figsize=(6.4, 2.9))
    for c, p, colr in CLASSES:
        ax.plot(NS, [price(SIZ[c], n)/1e6 for n in NS], color=colr, label=f"Class {c} ({p} kg)")
    ax.plot(ELECTRON_N, ELECTRON_ASP_EUR/1e6, "D", ms=7, color=INK, mec="white", mew=1.5, zorder=4)
    ax.annotate("Electron 2025\n(21 launches, ASP)", (ELECTRON_N, ELECTRON_ASP_EUR/1e6), xytext=(8, 8),
                textcoords="offset points", fontsize=7, color=INK2)
    ax.plot(9.5, 19*USD2EUR, "D", ms=7, color=INK2, mec="white", mew=1.5, zorder=4)
    ax.annotate("Alpha list price", (9.5, 19*USD2EUR), xytext=(8, 4), textcoords="offset points",
                fontsize=7, color=INK2)
    ax.set_xlabel("Launches per year (N)"); ax.set_ylabel("Price per launch (EUR M)")
    ax.set_ylim(0, 35); ax.set_xlim(2, 30); ax.legend(loc="upper right", fontsize=7.4)
    fig.savefig(os.path.join(FIG, "price_cadence.pdf")); plt.close(fig)

def fig_perkg():
    fig, ax = plt.subplots(figsize=(6.4, 3.0))
    for c, p, colr in CLASSES:
        ax.plot(NS, [price(SIZ[c], n)/p/1e3 for n in NS], color=colr, label=f"Class {c} ({p} kg), full")
    ax.axhline(RIDE_KG/1e3, color=INK2, lw=1.4, ls=(0, (4, 2)))
    ax.text(30, RIDE_KG/1e3+1.2, "Rideshare marginal rate (~EUR 6.0 k/kg)", ha="right", fontsize=7, color=INK2)
    ax.plot(ELECTRON_N, ELECTRON_ASP_EUR/200/1e3, "D", ms=7, color=INK, mec="white", mew=1.5, zorder=4)
    ax.annotate("Electron 2025", (ELECTRON_N, ELECTRON_ASP_EUR/200/1e3), xytext=(6, 6),
                textcoords="offset points", fontsize=7, color=INK2)
    ax.set_xlabel("Launches per year (N)"); ax.set_ylabel("Price per kg, full load (EUR k/kg)")
    ax.set_ylim(0, 110); ax.set_xlim(2, 30); ax.legend(loc="upper right", fontsize=7.4)
    fig.savefig(os.path.join(FIG, "perkg_cadence.pdf")); plt.close(fig)

def fig_anchor():
    fig, ax = plt.subplots(figsize=(6.4, 3.1))
    pp = np.linspace(100, 2500, 200)
    ax.plot(pp, [rideshare(m)/m/1e3 for m in pp], color=INK2, lw=1.4, ls=(0, (4, 2)))
    ax.text(105, 7.6, "Rideshare (50 kg block + per-kg rate)", ha="left", fontsize=7, color=INK2)
    OFF = {"Electron (2025 ASP)": (8, -3), "Alpha (list, PUG 5.2)": (8, 2), "Vega-C (Sentinel-1C)": (-10, 8),
           "Spectrum (target)": (8, 4), "RFA One (2021 claim)": (8, -2)}
    for n, p, pr, kind, colr in ANCH:
        filled = kind == "price"
        ax.plot(p, pr/p/1e3, "o", ms=8, color=colr if filled else "white", mec=colr, mew=1.8, zorder=4)
        ax.annotate(n, (p, pr/p/1e3), xytext=OFF[n], textcoords="offset points", fontsize=7, color=INK,
                    ha="right" if OFF[n][0] < 0 else "left")
    for c, p, colr in CLASSES:
        v = price(SIZ[c], 10)/p/1e3
        ax.plot(p, v, "s", ms=7, color=colr, mec="white", mew=1.5, zorder=5)
        ax.annotate(f"Model {c}, N=10", (p, v), xytext=(-8, 4) if c != "A" else (8, 0), textcoords="offset points",
                    fontsize=7, color=colr, ha="right" if c != "A" else "left")
    ax.set_xscale("log"); ax.set_xlim(90, 3200); ax.set_ylim(0, 70)
    ax.set_xticks([100, 200, 400, 600, 1000, 2000]); ax.set_xticklabels(["100", "200", "400", "600", "1000", "2000"])
    ax.set_xlabel("SSO payload capacity (kg, log scale)"); ax.set_ylabel("Price per kg at full load (EUR k/kg)")
    ax.text(95, 66, "filled = observed price   hollow = announced target / claim", fontsize=7, color=INK2)
    fig.savefig(os.path.join(FIG, "anchors.pdf")); plt.close(fig)

def fig_single_sat():
    """Cost for one customer to fly one satellite of mass m (N = 10/yr)."""
    ms = np.arange(20, 621, 5)
    fig, ax = plt.subplots(figsize=(6.4, 3.0))
    ax.plot(ms, [rideshare(m)/1e6 for m in ms], color=INK2, lw=1.4, ls=(0, (4, 2)), label="Rideshare (SSO, fixed schedule)")
    for c, p, colr in CLASSES:
        use = 0.85*p
        pr = price(SIZ[c], 10)/1e6
        x = ms[ms <= use]
        ax.plot(x, [pr]*len(x), color=colr, label=f"Dedicated class {c} (usable {use:.0f} kg)")
        ax.plot(x[-1], pr, "o", ms=5, color=colr)
    ax.set_xlabel("Mass of a single satellite (kg)"); ax.set_ylabel("Launch cost to customer (EUR M)")
    ax.set_ylim(0, 22); ax.set_xlim(0, 620); ax.legend(loc="upper left", fontsize=7.2)
    fig.savefig(os.path.join(FIG, "single_sat.pdf")); plt.close(fig)

def breakeven(s, target):
    for n in range(1, 200):
        if price(s, n) <= target*(1+1e-9): return n
    return None

# ------------------------------------------------------------------ tables
def fm(x, nd=0):
    s = f"{x:,.{nd}f}".replace(",", r"\,")
    return s

def write(name, txt):
    open(os.path.join(GEN, name), "w").write(txt)

def tables():
    rows = []
    for c in ["A", "B", "C", "D"]:
        s = SIZ[c]; cveh, cops, F = costs(s)
        rows.append((c, s, cveh, cops, F))
    t = [r"\begin{tabular}{lrrrr}\toprule",
         r"Quantity & Class A & Class B & Class C & Ref.\ 1\,t \\ \midrule"]
    def line(lbl, f, nd=0):
        t.append(lbl + " & " + " & ".join(fm(f(r), nd) for r in rows) + r" \\")
    line("SSO payload (kg)", lambda r: r[1]["pl"])
    line("Lift-off mass (t)", lambda r: r[1]["glom"]/1000, 1)
    line("Total propellant (t)", lambda r: r[1]["mprop"]/1000, 1)
    line("Total inert mass (kg)", lambda r: r[1]["mdry"])
    line(r"Mean inert fraction $\bar\varepsilon$ (\%)", lambda r: 100*r[1]["eps_avg"], 1)
    line(r"Payload fraction $\lambda$ (\%)", lambda r: 100*r[1]["lam"], 2)
    line("Lift-off thrust at T/W = 1.4 (kN)", lambda r: 1.4*r[1]["glom"]*G0/1000)
    t.append(r"\midrule")
    line(r"Recurring vehicle cost (\texteuro\,M)", lambda r: r[2]/1e6, 2)
    line(r"Launch operations per mission (\texteuro\,M)", lambda r: r[3]/1e6, 2)
    line(r"Fixed annual cost (\texteuro\,M/yr)", lambda r: r[4]/1e6, 1)
    for n in (5, 10, 20):
        line(rf"Price at $N={n}$/yr (\texteuro\,M)", lambda r, n=n: price(r[1], n)/1e6, 1)
        line(rf"\quad per kg, full load (\texteuro\,k/kg)", lambda r, n=n: price(r[1], n)/r[1]["pl"]/1e3, 1)
    t.append(r"\bottomrule\end{tabular}")
    write("class_table.tex", "\n".join(t))

    # sensitivity: price per kg at N=10 vs b exponent and F0
    t = [r"\begin{tabular}{llrrrr}\toprule",
         r"Case & Parameter & A (\texteuro\,k/kg) & B (\texteuro\,k/kg) & C (\texteuro\,k/kg) & B/A ratio \\ \midrule"]
    cases = [("Baseline", r"$b=0.60$, $F_0=35$", {}),
             ("Weak scale economy", r"$b=0.75$", {"b": 0.75}),
             ("Strong scale economy", r"$b=0.50$", {"b": 0.50}),
             ("Lean organisation", r"$F_0=20$", {"f0": 20e6}),
             ("Heavy organisation", r"$F_0=60$", {"f0": 60e6})]
    sens = {}
    for name, par, kw in cases:
        v = [price(SIZ[c], 10, **kw)/SIZ[c]["pl"]/1e3 for c in "ABC"]
        sens[name] = v
        t.append(f"{name} & {par} & {v[0]:.1f} & {v[1]:.1f} & {v[2]:.1f} & {v[1]/v[0]:.2f} \\\\")
    t.append(r"\bottomrule\end{tabular}")
    write("sens_table.tex", "\n".join(t))

    # break-even cadence table
    tgt = [("Match Electron 2025 ASP per launch (\\texteuro\\,%.1f\\,M)" % (ELECTRON_ASP_EUR/1e6), lambda p: ELECTRON_ASP_EUR),
           ("Match Alpha list price per kg (\\texteuro\\,%.1f\\,k/kg)" % (19e6*USD2EUR/630/1e3), lambda p: 19e6*USD2EUR/630*p),
           ("Reach \\texteuro\\,20\\,k/kg at full load", lambda p: 20e3*p),
           ("Reach \\texteuro\\,15\\,k/kg at full load", lambda p: 15e3*p)]
    t = [r"\begin{tabular}{lrrr}\toprule",
         r"Price target & Class A & Class B & Class C \\ \midrule"]
    be = {}
    for lbl, f in tgt:
        v = [breakeven(SIZ[c], f(SIZ[c]["pl"])) for c in "ABC"]
        be[lbl] = v
        t.append(lbl + " & " + " & ".join("--" if x is None or x > 60 else str(x) for x in v) + r" \\")
    t.append(r"\bottomrule\end{tabular}")
    write("breakeven_table.tex", "\n".join(t))
    return sens, be

if __name__ == "__main__":
    fig_market(); fig_sizing(); fig_price_cadence(); fig_perkg(); fig_anchor(); fig_single_sat()
    sens, be = tables()
    out = dict(k=k, siz={c: SIZ[c] for c in SIZ},
               costs={c: costs(SIZ[c]) for c in SIZ},
               price10={c: price(SIZ[c], 10) for c in SIZ},
               price5={c: price(SIZ[c], 5) for c in SIZ},
               price20={c: price(SIZ[c], 20) for c in SIZ},
               ride={m: rideshare(m) for m in (100, 150, 200, 400)}, sens=sens, be=be,
               electron_eur=ELECTRON_ASP_EUR)
    json.dump(out, open(os.path.join(GEN, "model.json"), "w"), indent=1, default=float)
    for c in SIZ: print(c, {kk: round(v, 4) if isinstance(v, float) else v for kk, v in SIZ[c].items()})
    for c in SIZ: print(c, [round(x/1e6, 2) for x in costs(SIZ[c])], round(price(SIZ[c], 10)/1e6, 2), round(price(SIZ[c], 5)/1e6,2), round(price(SIZ[c], 20)/1e6,2))
    print("k", k); print(sens); print(be)
