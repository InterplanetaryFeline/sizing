#!/usr/bin/env python3
"""
Engineering calculations, LaTeX table generation and figure generation for
the micro-launcher comparative study.  Run from the report root:
    python3 scripts/analysis.py
All outputs go to generated/ (tables, CSV, XLSX) and figures/ (PDF).
"""
import json, math, os, sys, csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Rectangle, FancyArrowPatch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "data"))
from vehicles import VEH, ORDER, SHORT, SCHEMATIC, SLIP  # noqa

GEN = os.path.join(ROOT, "generated")
FIG = os.path.join(ROOT, "figures")
G0 = 9.80665

# ----------------------------------------------------------------------------
# Palette (reference palette from the dataviz method; light mode, print)
# ----------------------------------------------------------------------------
C_EU, C_INT, C_FAIL = "#2a78d6", "#eb6834", "#8a8984"
C_GOOD, C_CRIT, C_WARN = "#0ca30c", "#d03b3b", "#fab219"
INK, INK2, GRID, AXIS = "#0b0b0b", "#52514e", "#e1e0d9", "#c3c2b7"
GROUP_COLOR = {"eu": C_EU, "int": C_INT, "fail": C_FAIL}
GROUP_LABEL = {"eu": "European (active)", "int": "International reference (active)",
               "fail": "Cancelled / discontinued"}

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8.5, "axes.edgecolor": AXIS,
    "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
    "axes.titlesize": 9.5, "axes.titleweight": "bold", "axes.titlecolor": INK,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
    "grid.color": GRID, "grid.linewidth": 0.6, "legend.frameon": False,
    "savefig.bbox": "tight", "savefig.dpi": 300, "lines.linewidth": 2,
})

# ----------------------------------------------------------------------------
# Helpers for LaTeX formatting
# ----------------------------------------------------------------------------
NDTXT = r"\textit{Not publicly disclosed}"
NDSHORT = r"\textit{n.d.}"

def fnum(x, nd=0):
    if isinstance(x, str):
        return (x.replace("%", r"\%").replace("x ", r"$\times$ ").replace("&", r"\&")
                 .replace("/", r"/\allowbreak{}").replace("N2O", r"N$_2$O"))
    if x is None:
        return None
    if nd == 0 and abs(x - round(x)) < 1e-9:
        s = f"{int(round(x)):,}"
    else:
        s = f"{x:,.{nd}f}" if nd else f"{x:,.2f}".rstrip("0").rstrip(".")
    return s.replace(",", r"\,")

def cell(val, short=False, tag=True, nd=0):
    if val is None or val.get("c") == "ND" or val.get("v") is None:
        return NDSHORT if short else NDTXT
    s = fnum(val["v"], nd)
    if tag:
        s += r"\textsuperscript{\,%s}" % val["c"]
    return s

def cites(*vals):
    keys = []
    for v in vals:
        if v is None:
            continue
        for k in v.get("s", []):
            if k not in keys:
                keys.append(k)
    return (r"\cite{" + ",".join(keys) + "}") if keys else "--"

def tex_escape(s):
    return (s.replace("&", r"\&").replace("%", r"\%").replace("_", r"\_")
             .replace("#", r"\#"))

def write(name, text):
    with open(os.path.join(GEN, name), "w") as f:
        f.write(text)

def num(val):
    if val is None or val.get("c") == "ND":
        return None
    return val["v"] if isinstance(val["v"], (int, float)) else None

# ----------------------------------------------------------------------------
# 1. Rocket-equation tools
# ----------------------------------------------------------------------------
def optimal_payload_fraction(dv, c_list, eps_list):
    """Lagrange-multiplier optimal staging (serial stages).
    Returns overall payload fraction m_pl/m_0 and per-stage mass ratios n_i.
    n_i = (eta*c_i - 1)/(eta*c_i*eps_i);  sum c_i ln n_i = dv."""
    c = np.array(c_list, float); e = np.array(eps_list, float)
    def f(eta):
        n = (eta * c - 1) / (eta * c * e)
        if np.any(n <= 1):
            return -dv
        return np.sum(c * np.log(n)) - dv
    lo = 1.0 / c.min() * (1 + 1e-9); hi = lo * 2
    while f(hi) < 0:
        hi *= 2
        if hi > 1e3:
            return None, None
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if f(mid) > 0: hi = mid
        else: lo = mid
    eta = 0.5 * (lo + hi)
    n = (eta * c - 1) / (eta * c * e)
    pi = (1 - e * n) / ((1 - e) * n)
    if np.any(pi <= 0):
        return None, None
    return float(np.prod(pi)), n

def implied_eps(dv, isp_list, lam_target):
    """Common structural coefficient that makes an optimally staged vehicle
    deliver payload fraction lam_target over ideal delta-v dv.  Scans eps
    downward from 0.40 (payload fraction rises as eps falls) and stops at the
    first crossing; degenerate optima (a stage with mass ratio < 1.05) are
    rejected so that every stage keeps doing useful work."""
    c = [i * G0 for i in isp_list]
    def lam(e):
        r, n = optimal_payload_fraction(dv, c, [e] * len(c))
        if r is None or np.any(n < 1.05):
            return None
        return r
    grid = np.arange(0.40, 0.009, -0.0005)
    prev_e, prev_l = None, None
    for e in grid:
        l = lam(e)
        if l is None:
            if prev_l is not None:
                break
            continue
        if l >= lam_target:
            if prev_l is None:
                return float(e)
            # linear interpolation between grid points
            return float(prev_e + (lam_target - prev_l) * (e - prev_e) / (l - prev_l))
        prev_e, prev_l = e, l
    return None

def stage_breakdown(dv, isp_list, eps, m0):
    """Return list of (stage gross incl. upper composite, prop, dry) for an
    optimally staged vehicle of lift-off mass m0 at common eps."""
    c = [i * G0 for i in isp_list]
    lam, n = optimal_payload_fraction(dv, c, [eps] * len(c))
    out = []; m = m0
    for ni in n:
        mf = m / ni
        mp = m - mf
        ms = eps / (1 - eps) * mp
        out.append(dict(m0=m, mp=mp, ms=ms, stage=mp + ms))
        m = m - mp - ms
    return out, m  # m = payload

# Assumed effective (trajectory-averaged) specific impulses where the
# manufacturer has not published them, by propellant/cycle class.
# These are ENGINEERING ASSUMPTIONS (class E) and are listed in the report.
ISP_ASSUMED = {
    "electron":    ([311 * 1.035, 343], "S1 = 1.035 x published SL Isp; S2 published vac"),
    "alpha":       ([296 * 0.95, 322], "S1 = 0.95 x published vac Isp; S2 published vac"),
    "miura5":      ([295, 330], "LOX/RP-1 gas-generator class (assumed)"),
    "prime":       ([290, 315], "LOX/propane, small GG S1 / pressure-fed S2 (assumed)"),
    "skyrora":     ([265, 300, 300], "HTP/kerosene class (assumed)"),
    "sl1":         ([280, 310, 315], "paraffin/LOX hybrid class (assumed)"),
    "launcherone": ([310, 330], "air-launched LOX/RP-1; S1 near-vacuum (assumed)"),
}
DV_REQ = {  # ideal (Tsiolkovsky) delta-v requirement assumptions, m/s
    "SSO500": 9600.0, "LEO": 9300.0, "SSO500_AIR": 9100.0,
}
CASE = {  # vehicle: (payload field, dv case)
    "electron": ("sso", "SSO500"), "alpha": ("sso", "SSO500"),
    "miura5": ("sso", "SSO500"), "prime": ("sso", "SSO500"),
    "skyrora": ("sso", "SSO500"), "sl1": ("leo", "LEO"),
    "launcherone": ("sso", "SSO500_AIR"),
}

def vegac_validation():
    v = VEH["vegac"]
    st = v["stages"]
    pl = 2423.0; fairing = 860.0
    wet = [s["wet"]["v"] for s in st]; prop = [s["prop"]["v"] for s in st]
    dry = [w - p for w, p in zip(wet, prop)]; dry[3] = 695.0
    isp = [279 * 0.95, 293.5, 295.9, 315.8]
    m = sum(wet) + fairing + pl
    rows = []; total = 0
    for i in range(4):
        if i == 2:
            m -= fairing  # fairing jettison assumed at Z9 ignition
        m0 = m; mf = m0 - prop[i]
        dv = isp[i] * G0 * math.log(m0 / mf)
        total += dv
        eps = dry[i] / wet[i]
        rows.append(dict(stage=st[i]["name"], m0=m0, mf=mf, isp=isp[i], dv=dv, eps=eps,
                         pmf=prop[i] / wet[i]))
        m = mf - dry[i]
    return rows, total

# ----------------------------------------------------------------------------
# 2. Derived metrics for every vehicle
# ----------------------------------------------------------------------------
def to_eur(x, cur):
    # Fixed conversion for indicative comparison only (assumption, see report):
    rate = {"EUR": 1.0, "USD": 0.86, "GBP": 1.15, "AUD": 0.56}[cur]
    return x * rate

metrics = {}
for k in ORDER:
    v = VEH[k]
    L, D = num(v["length"]), num(v["diameter"])
    m0 = num(v["glom"]); T = num(v["liftoff_thrust"])
    sso, leo = num(v["sso"]), num(v["leo"])
    m = dict(LD=L / D if L and D else None)
    m["lam_sso"] = sso / m0 if (sso and m0) else None
    m["lam_leo"] = leo / m0 if (leo and m0) else None
    m["tw"] = T * 1e3 / (m0 * G0) if (T and m0) else None
    # cost per kg (advertised)
    price = num(v["price"])
    if price:
        m["price_eur"] = to_eur(price, v["currency"])
        m["cpk_sso"] = price / sso if sso else None
        m["cpk_leo"] = price / leo if leo else None
    elif num(v.get("price_per_kg", None) or {"c": "ND", "v": None}):
        m["cpk_target"] = v["price_per_kg"]["v"]
    # GLOM estimate from thrust (T/W 1.3-1.5) where GLOM unknown
    if not m0 and T:
        m["glom_est"] = (T * 1e3 / (1.5 * G0), T * 1e3 / (1.3 * G0))
    metrics[k] = m

# implied structural coefficients
eps_res = {}
for k, (pf, case) in CASE.items():
    v = VEH[k]; m0 = num(v["glom"]); pl = num(v[pf])
    isp, note = ISP_ASSUMED[k]
    lam_t = pl / m0
    dv = DV_REQ[case]
    e_nom = implied_eps(dv, isp, lam_t)
    e_lo = implied_eps(dv + 200, isp, lam_t)   # harder mission -> lower eps
    e_hi = implied_eps(dv - 200, isp, lam_t)
    br, plx = stage_breakdown(dv, isp, e_nom, m0) if e_nom else (None, None)
    eps_res[k] = dict(e=e_nom, lo=e_lo, hi=e_hi, isp=isp, note=note, dv=dv,
                      lam=lam_t, pl=pl, m0=m0, case=case, pf=pf, breakdown=br)

veg_rows, veg_dv = vegac_validation()

# plausibility check for vehicles with thrust but no GLOM
plaus = {}
PLAUS_ISP = {"spectrum": [300, 340], "rfaone": [320, 350], "maia": [320, 360],
             "rs1": [300, 330], "rocket3": [295, 320]}
PLAUS_PL = {"spectrum": ("sso", "SSO500"), "rfaone": ("sso", "SSO500"),
            "maia": ("sso", "SSO500"), "rs1": ("sso", "SSO500"), "rocket3": ("sso", "SSO500")}
for k, isp in PLAUS_ISP.items():
    T = num(VEH[k]["liftoff_thrust"])
    lo, hi = T * 1e3 / (1.5 * G0), T * 1e3 / (1.3 * G0)
    pf, case = PLAUS_PL[k]
    res = []
    for e in (0.10, 0.08):
        lam, _ = optimal_payload_fraction(DV_REQ[case], [i * G0 for i in isp], [e, e])
        res.append(lam)
    plaus[k] = dict(m0=(lo, hi), isp=isp, lam10=res[0], lam08=res[1],
                    pl=(lo * res[0], hi * res[1]), adv=num(VEH[k][pf]))

json.dump(dict(metrics={k: {kk: (list(vv) if isinstance(vv, tuple) else vv) for kk, vv in m.items()} for k, m in metrics.items()},
               eps={k: {kk: vv for kk, vv in r.items() if kk != "breakdown"} for k, r in eps_res.items()},
               vegac=dict(rows=veg_rows, dv=veg_dv),
               plaus={k: {kk: (list(vv) if isinstance(vv, tuple) else vv) for kk, vv in r.items()} for k, r in plaus.items()}),
          open(os.path.join(GEN, "metrics.json"), "w"), indent=1, default=float)

# ----------------------------------------------------------------------------
# 3. Per-vehicle LaTeX tables
# ----------------------------------------------------------------------------
LEG = (r"\par\smallskip\footnotesize\textit{Data classes:} M = manufacturer, "
       r"G = government/agency, S = secondary source, F = flight record, "
       r"D = derived arithmetically from cited values.")

def stage_table(k):
    v = VEH[k]; st = v["stages"]; ns = len(st)
    rows = [("Stage name", "name", ""), ("Stage number", "number", ""),
            ("Stage length", "length", "m"), ("Stage diameter", "diameter", "m"),
            ("Dry (inert) mass", "dry", "kg"), ("Propellant mass", "prop", "kg"),
            ("Wet (gross) mass", "wet", "kg"), ("Propellant combination", "propellant", ""),
            ("Number of engines", "n_eng", ""), ("Engine name", "engine", ""),
            ("Specific impulse (sea level)", "isp_sl", "s"),
            ("Specific impulse (vacuum)", "isp_vac", "s"),
            ("Thrust (stage total)", "thrust", "kN")]
    colw = {2: "3.0cm", 3: "2.45cm", 4: "1.95cm"}[ns]
    out = [r"\begin{table}[htbp]\centering\footnotesize",
           r"\caption{%s -- stage-by-stage technical data.}\label{tab:%s-stages}" % (tex_escape(v["name"]), k),
           r"\renewcommand{\arraystretch}{1.12}",
           r"\begin{tabularx}{\textwidth}{@{}>{\raggedright}p{2.9cm}" + (r">{\raggedright\arraybackslash}p{%s}" % colw) * ns +
           r"l>{\raggedright\arraybackslash}X@{}}", r"\toprule",
           "Parameter & " + " & ".join(r"\textbf{S%d}" % (i + 1) for i in range(ns)) + r" & Unit & Source \\", r"\midrule"]
    for label, key, unit in rows:
        if key in ("name", "number"):
            vals = [tex_escape(str(s[key])) for s in st]
            out.append(label + " & " + " & ".join(vals) + " & " + unit + r" & -- \\")
            continue
        vals = [cell(s[key], tag=True, nd=2 if key in ("length", "diameter") else 0) for s in st]
        out.append(label + " & " + " & ".join(vals) + " & " + unit + " & " + cites(*[s[key] for s in st]) + r" \\")
    out += [r"\bottomrule", r"\end{tabularx}", LEG, r"\end{table}"]
    write(f"{k}_stages.tex", "\n".join(out) + "\n")

def totals_table(k):
    v = VEH[k]
    rows = [("Total vehicle length", v["length"], "m", 2), ("Maximum vehicle diameter", v["diameter"], "m", 2),
            ("Lift-off mass (GLOM)", v["glom"], "kg", 0), ("Total propellant mass", v["prop_total"], "kg", 0),
            ("Total dry mass", v["dry_total"], "kg", 0), ("Number of stages", v["stages_n"], "--", 0),
            ("Total number of engines", v["n_engines"], "--", 0),
            ("Lift-off thrust", v["liftoff_thrust"], "kN", 1)]
    out = [r"\begin{table}[htbp]\centering\footnotesize",
           r"\caption{%s -- total vehicle specifications.}\label{tab:%s-totals}" % (tex_escape(v["name"]), k),
           r"\begin{tabularx}{\textwidth}{@{}lrlX@{}}", r"\toprule",
           r"Parameter & Value & Unit & Source / note \\", r"\midrule"]
    for lab, val, unit, nd in rows:
        note = tex_escape(val.get("n", "")) if val else ""
        src = cites(val)
        out.append(f"{lab} & {cell(val, nd=nd)} & {unit} & {src}" + (f" {note}" if note else "") + r" \\")
    out += [r"\bottomrule", r"\end{tabularx}", LEG, r"\end{table}"]
    write(f"{k}_totals.tex", "\n".join(out) + "\n")

def perf_table(k, extra_rows=()):
    v = VEH[k]
    rows = [("Max. payload, LEO", v["leo"], "kg", v["leo_orbit"]),
            ("Max. payload, SSO", v["sso"], "kg", v["sso_orbit"])]
    rows += list(extra_rows)
    rows += [("Fairing diameter", v["fairing_d"], "m", ""), ("Fairing length", v["fairing_l"], "m", ""),
             ("Usable fairing volume", v["fairing_vol"], "m$^3$", "")]
    out = [r"\begin{table}[htbp]\centering\footnotesize",
           r"\caption{%s -- performance and payload accommodation.}\label{tab:%s-perf}" % (tex_escape(v["name"]), k),
           r"\begin{tabularx}{\textwidth}{@{}lrl>{\raggedright}p{3.4cm}>{\raggedright\arraybackslash}X@{}}", r"\toprule",
           r"Parameter & Value & Unit & Reference orbit & Source / note \\", r"\midrule"]
    for lab, val, unit, orb in rows:
        note = tex_escape(val.get("n", "")) if val else ""
        nd = 3 if unit == "m" else 0
        out.append(f"{lab} & {cell(val, nd=nd)} & {unit} & {tex_escape(orb)} & {cites(val)} {note}" + r" \\")
    out += [r"\bottomrule", r"\end{tabularx}",
            r"\par\smallskip\footnotesize Values tagged M/G are advertised (not independently verified) "
            r"unless the flight-record column of the launch history shows a demonstrated mission.",
            r"\end{table}"]
    write(f"{k}_perf.tex", "\n".join(out) + "\n")

def econ_table(k):
    v = VEH[k]; m = metrics[k]
    price = v["price"]
    lines = []
    if num(price):
        cur = v["currency"]
        for orb, pf in (("SSO", "sso"), ("LEO", "leo")):
            pl = num(v[pf])
            if pl:
                lines.append((orb, v[pf + "_orbit"], pl, num(price) / pl, v[pf]))
    out = [r"\begin{table}[htbp]\centering\footnotesize",
           r"\caption{%s -- indicative launch economics (advertised price / maximum advertised payload).}\label{tab:%s-econ}" % (tex_escape(v["name"]), k),
           r"\begin{tabularx}{\textwidth}{@{}l>{\raggedright\arraybackslash}X@{}}", r"\toprule"]
    if num(price):
        out.append(r"Advertised / reported price & %s %s M\textsuperscript{\,%s} %s %s \\" % (
            v["currency"], fnum(num(price) / 1e6, 2), price["c"], cites(price), tex_escape(price.get("n", ""))))
        for orb, orbit, pl, cpk, pv in lines:
            out.append(r"Cost per kg, %s & %s %s/kg (payload %s kg, %s) %s \\" % (
                orb, v["currency"], fnum(round(cpk, -1)), fnum(pl), tex_escape(orbit), cites(pv)))
    else:
        out.append(r"Advertised price & \textit{Not publicly disclosed}%s \\" % (
            (" -- " + tex_escape(price.get("n", ""))) if price.get("n") else ""))
        if "cpk_target" in m:
            ppk = v["price_per_kg"]
            out.append(r"Advertised target price per kg & %s %s/kg\textsuperscript{\,%s} %s (%s) \\" % (
                v["currency"], fnum(ppk["v"]), ppk["c"], cites(ppk), tex_escape(ppk["n"])))
        else:
            out.append(r"Cost per kg & \textit{Cannot be calculated without a published price.} \\")
    out += [r"\bottomrule", r"\end{tabularx}", r"\end{table}"]
    write(f"{k}_econ.tex", "\n".join(out) + "\n")

EXTRA = {
    "rfaone": [("Payload, polar 2,000 km", {"v": 850, "c": "M", "s": ["rfa_launcher"], "n": ""}, "kg", "2,000 km polar"),
               ("Payload, MEO 6,000 km", {"v": 500, "c": "M", "s": ["rfa_launcher"], "n": ""}, "kg", "6,000 km"),
               ("Payload, GTO", {"v": 450, "c": "M", "s": ["rfa_launcher"], "n": ""}, "kg", "GTO"),
               ("Payload, SSO (current config.)", VEH["rfaone"]["sso_current"], "kg", "500 km SSO")],
    "vegac": [("Payload, SSO 700 km", {"v": 2266, "c": "M", "s": ["avio_um_vegac"], "n": ""}, "kg", "710 x 690 km, 98.2°"),
              ("Payload, LEO 500 km 70°", {"v": 2470, "c": "M", "s": ["avio_um_vegac"], "n": ""}, "kg", "500 km, 70°"),
              ("Payload, equatorial", {"v": 3000, "c": "M", "s": ["avio_um_vegac"], "n": "'> 3,000 kg'"}, "kg", "500 km, 5.2°")],
    "maia": [("Payload, SSO, reusable", VEH["maia"]["sso_reuse"], "kg", "first stage recovered")],
    "electron": [],
    "alpha": [],
}

for k in ORDER:
    stage_table(k); totals_table(k); perf_table(k, EXTRA.get(k, ())); econ_table(k)

# ----------------------------------------------------------------------------
# 4. Estimates tables (implied structural coefficient, stage breakdown)
# ----------------------------------------------------------------------------
def est_table(k):
    r = eps_res.get(k)
    out = []
    if r and r["e"]:
        out += [r"\begin{table}[htbp]\centering\footnotesize",
                r"\caption{%s -- engineering estimates (class E). Optimal-staging reconstruction at the implied common structural coefficient; not manufacturer data.}\label{tab:%s-est}" % (tex_escape(VEH[k]["name"]), k),
                r"\begin{tabularx}{\textwidth}{@{}lrX@{}}", r"\toprule", r"Quantity & Value & Basis \\", r"\midrule",
                r"Payload fraction $\lambda = m_\mathrm{pl}/m_0$ & %.2f\,\%% & %s kg / %s kg (cited values) \\" % (100 * r["lam"], fnum(r["pl"]), fnum(r["m0"])),
                r"Ideal $\Delta v$ requirement assumed & %.1f km/s & %s case, see Sec.~\ref{sec:method-dv} \\" % (r["dv"] / 1000, r["case"].replace("_", r"\_")),
                r"Effective $I_\mathrm{sp}$ used & %s s & %s \\" % (" / ".join(f"{i:.0f}" for i in r["isp"]), tex_escape(r["note"])),
                r"Implied common structural coefficient $\varepsilon$ & %.3f & range %.3f--%.3f for $\Delta v \pm 0.2$ km/s \\" % (r["e"], r["lo"] or 0, r["hi"] or 0)]
        for i, b in enumerate(r["breakdown"]):
            out.append(r"Stage %d estimated propellant / dry mass & %s / %s kg & optimal split; real vehicles deviate \\" % (
                i + 1, fnum(round(b["mp"], -1)), fnum(round(b["ms"], -1))))
        out += [r"\bottomrule", r"\end{tabularx}", r"\end{table}"]
    elif k in plaus:
        p = plaus[k]
        out += [r"\begin{table}[htbp]\centering\footnotesize",
                r"\caption{%s -- engineering estimates (class E): lift-off mass from thrust and payload plausibility. Not manufacturer data.}\label{tab:%s-est}" % (tex_escape(VEH[k]["name"]), k),
                r"\begin{tabularx}{\textwidth}{@{}lrX@{}}", r"\toprule", r"Quantity & Value & Basis \\", r"\midrule",
                r"Lift-off thrust used & %s kN & cited value (Table~\ref{tab:%s-totals}) \\" % (fnum(num(VEH[k]["liftoff_thrust"]), 1), k),
                r"Estimated GLOM range & %s--%s t & lift-off $T/W$ = 1.5--1.3 \\" % (fnum(p["m0"][0] / 1000, 1), fnum(p["m0"][1] / 1000, 1)),
                r"Effective $I_\mathrm{sp}$ assumed & %s s & propellant-class assumption \\" % " / ".join(str(i) for i in p["isp"]),
                r"Payload fraction (optimal staging, $\varepsilon$=0.10 / 0.08) & %.2f / %.2f\,\%% & 9.6 km/s, two stages \\" % (100 * p["lam10"], 100 * p["lam08"]),
                r"Implied SSO payload range & %s--%s kg & low GLOM $\times$ $\varepsilon$=0.10 to high GLOM $\times$ $\varepsilon$=0.08 \\" % (fnum(round(p["pl"][0], -1)), fnum(round(p["pl"][1], -1))),
                r"Advertised SSO payload & %s kg & Table~\ref{tab:%s-perf} \\" % (fnum(p["adv"]), k),
                r"\bottomrule", r"\end{tabularx}", r"\end{table}"]
    else:
        out.append(r"\noindent\textit{No defensible numerical estimate is offered for this vehicle: neither lift-off mass nor lift-off thrust has been published, so any mass breakdown would be invented rather than derived.}" + "\n")
    write(f"{k}_est.tex", "\n".join(out) + "\n")

for k in ORDER:
    est_table(k)

# Vega-C validation table
vv = [r"\begin{table}[htbp]\centering\footnotesize",
      r"\caption{Method validation on Vega-C: ideal $\Delta v$ reconstructed from User's Manual stage masses for the 2,423 kg / 500 km SSO case \cite{avio_um_vegac}.}\label{tab:vegac-dv}",
      r"\begin{tabular}{@{}lrrrrrr@{}}", r"\toprule",
      r"Stage & $m_0$ [kg] & $m_f$ [kg] & $I_\mathrm{sp}$ used [s] & $\Delta v$ [m/s] & $\varepsilon$ & $m_p/m_\mathrm{stage}$ \\", r"\midrule"]
for r in veg_rows:
    vv.append(r"%s & %s & %s & %.1f & %s & %.3f & %.3f \\" % (r["stage"], fnum(round(r["m0"])), fnum(round(r["mf"])), r["isp"], fnum(round(r["dv"])), r["eps"], r["pmf"]))
vv += [r"\midrule", r"Total & & & & \textbf{%s} & & \\" % fnum(round(veg_dv)), r"\bottomrule", r"\end{tabular}",
       r"\par\smallskip\footnotesize P120C $I_\mathrm{sp}$ reduced to 95\,\% of vacuum value as a trajectory average; fairing (860 kg) assumed jettisoned at Zefiro 9 ignition; interstage masses assumed to be inside the published stage gross masses.",
       r"\end{table}"]
write("vegac_dv.tex", "\n".join(vv) + "\n")

# Implied-eps summary table
es = [r"\begin{table}[htbp]\centering\footnotesize",
      r"\caption{Implied common structural coefficient $\varepsilon$ that reconciles published lift-off mass and payload (class E estimate).}\label{tab:eps-summary}",
      r"\begin{tabular}{@{}lrrrrl@{}}", r"\toprule",
      r"Vehicle & $m_0$ [kg] & $m_\mathrm{pl}$ [kg] & $\lambda$ [\%] & $\varepsilon$ (range) & Case \\", r"\midrule"]
for k in ["electron", "alpha", "miura5", "skyrora", "sl1", "prime", "launcherone"]:
    r = eps_res[k]
    es.append(r"%s & %s & %s & %.2f & %.3f (%.3f--%.3f) & %s \\" % (SHORT[k], fnum(r["m0"]), fnum(r["pl"]), 100 * r["lam"], r["e"], r["lo"] or 0, r["hi"] or 0, r["case"].replace("_", r"\_")))
es += [r"\bottomrule", r"\end{tabular}", r"\par\smallskip\footnotesize Lower $\varepsilon$ = lighter structure required to make the published numbers consistent. For reference, Vega-C's flown solid stages have $\varepsilon$ = 0.073--0.119 and AVUM+ 0.48 (Table~\ref{tab:vegac-dv}).", r"\end{table}"]
write("eps_summary.tex", "\n".join(es) + "\n")

# ----------------------------------------------------------------------------
# 5. Consolidated comparison tables (3 landscape blocks of 5 vehicles)
# ----------------------------------------------------------------------------
def sstr(val, nd=0):
    return cell(val, short=True, tag=True, nd=nd)

def cmp_rows(k):
    v = VEH[k]; m = metrics[k]
    price = v["price"]
    if num(price):
        pr = r"%s %s M\textsuperscript{\,%s}" % (v["currency"], fnum(num(price) / 1e6, 2), price["c"])
    else:
        pr = NDSHORT
    cpk = []
    if m.get("cpk_sso"): cpk.append(r"%s/kg SSO" % fnum(round(m["cpk_sso"], -2)))
    if m.get("cpk_leo"): cpk.append(r"%s/kg LEO" % fnum(round(m["cpk_leo"], -2)))
    if m.get("cpk_target"): cpk.append(r"%s/kg (target)" % fnum(m["cpk_target"]))
    cpks = (v["currency"] + " " + "; ".join(cpk)) if cpk else NDSHORT
    isp = []
    for s in v["stages"]:
        a = num(s["isp_sl"]); b = num(s["isp_vac"])
        if a: isp.append(f"{a:.0f} SL")
        if b: isp.append(f"{b:.1f} vac".replace(".0 vac", " vac"))
    neng = "/".join(str(s["n_eng"]["v"]) if s["n_eng"]["v"] is not None else "?" for s in v["stages"])
    return {
        "Country": tex_escape(v["country"]),
        "Manufacturer": tex_escape(v["maker"]),
        "Vehicle status": tex_escape(v["status_vehicle"]),
        "Company status": tex_escape(v["status_company"]),
        "Number of stages": sstr(v["stages_n"]),
        "Propellants": tex_escape(v["propellants"]["v"]),
        "Total length [m]": sstr(v["length"], 1),
        "Max. diameter [m]": sstr(v["diameter"], 2),
        "Lift-off mass [kg]": sstr(v["glom"]),
        "Total propellant [kg]": sstr(v["prop_total"]),
        "Total dry mass [kg]": sstr(v["dry_total"]),
        "LEO payload [kg]": sstr(v["leo"]) + (r" \newline\scriptsize(" + tex_escape(v["leo_orbit"]) + ")" if num(v["leo"]) else ""),
        "SSO payload [kg]": sstr(v["sso"]) + (r" \newline\scriptsize(" + tex_escape(v["sso_orbit"]) + ")" if num(v["sso"]) else ""),
        "Engine configuration": tex_escape(v["engines_desc"]["v"]),
        "Engines per stage": neng,
        "Specific impulse [s]": (", ".join(isp) if isp else NDSHORT),
        "Reusability": tex_escape(v["reuse"]["v"]),
        "Advertised price": pr,
        "Indicative cost/kg": cpks,
        "First launch": tex_escape(v["first_launch"]["v"]),
        "Launches / successes": f"{v['launches']} / {v['successes']}" + (f" (+{v['partial']} partial)" if v["partial"] else ""),
    }

PARAMS = ["Country", "Manufacturer", "Vehicle status", "Company status", "Number of stages", "Propellants",
          "Total length [m]", "Max. diameter [m]", "Lift-off mass [kg]", "Total propellant [kg]", "Total dry mass [kg]",
          "LEO payload [kg]", "SSO payload [kg]", "Engine configuration", "Engines per stage", "Specific impulse [s]",
          "Reusability", "Advertised price", "Indicative cost/kg", "First launch", "Launches / successes"]
blocks = [ORDER[0:5], ORDER[5:10], ORDER[10:15]]
for bi, blk in enumerate(blocks):
    rows = {k: cmp_rows(k) for k in blk}
    out = [r"\begin{landscape}", r"\begin{table}[p]\centering\scriptsize",
           r"\caption{Consolidated technical comparison, part %d of 3 (n.d. = not publicly disclosed; superscripts = data class).}\label{tab:cmp%d}" % (bi + 1, bi + 1),
           r"\renewcommand{\arraystretch}{1.18}",
           r"\begin{tabularx}{\linewidth}{@{}>{\raggedright\bfseries}p{2.7cm}" + r">{\raggedright\arraybackslash}X" * len(blk) + r"@{}}",
           r"\toprule", "Parameter & " + " & ".join(r"\textbf{%s}" % SHORT[k] for k in blk) + r" \\", r"\midrule"]
    for p in PARAMS:
        out.append(p.replace("%", r"\%") + " & " + " & ".join(rows[k][p] for k in blk) + r" \\")
    out += [r"\bottomrule", r"\end{tabularx}", r"\end{table}", r"\end{landscape}"]
    write(f"comparison_{bi + 1}.tex", "\n".join(out) + "\n")

# CSV / XLSX export of the consolidated table (plain text, with source keys)
def plain(val, nd=0):
    if val is None or val.get("c") == "ND" or val.get("v") is None:
        return "Not publicly disclosed"
    return val["v"]

csv_rows = []
hdr = ["Vehicle", "Country", "Manufacturer", "Vehicle status", "Company status", "Stages", "Propellants",
       "Length_m", "Diameter_m", "GLOM_kg", "Total_propellant_kg", "Total_dry_kg", "LEO_payload_kg", "LEO_orbit",
       "SSO_payload_kg", "SSO_orbit", "Engine_configuration", "Liftoff_thrust_kN", "Reusability",
       "Advertised_price", "Currency", "Price_class", "Cost_per_kg_SSO", "Cost_per_kg_LEO", "Target_price_per_kg",
       "First_launch", "Launches", "Successes", "Partial_failures", "Length_to_diameter", "Payload_fraction_SSO_pct",
       "Liftoff_TW", "Key_sources"]
for k in ORDER:
    v = VEH[k]; m = metrics[k]
    srcs = sorted({s for f in ("length", "diameter", "glom", "leo", "sso", "price", "engines_desc") for s in v[f]["s"]})
    csv_rows.append([v["name"], v["country"], v["maker"], v["status_vehicle"], v["status_company"], plain(v["stages_n"]),
                     v["propellants"]["v"], plain(v["length"]), plain(v["diameter"]), plain(v["glom"]),
                     plain(v["prop_total"]), plain(v["dry_total"]), plain(v["leo"]), v["leo_orbit"], plain(v["sso"]),
                     v["sso_orbit"], v["engines_desc"]["v"], plain(v["liftoff_thrust"]), v["reuse"]["v"],
                     plain(v["price"]), v["currency"], v["price"]["c"], round(m["cpk_sso"]) if m.get("cpk_sso") else "",
                     round(m["cpk_leo"]) if m.get("cpk_leo") else "", m.get("cpk_target", ""), v["first_launch"]["v"],
                     v["launches"], v["successes"], v["partial"], round(m["LD"], 1) if m["LD"] else "",
                     round(100 * m["lam_sso"], 2) if m.get("lam_sso") else "", round(m["tw"], 2) if m.get("tw") else "",
                     "; ".join(srcs)])
with open(os.path.join(GEN, "consolidated_comparison.csv"), "w", newline="") as f:
    w = csv.writer(f); w.writerow(hdr); w.writerows(csv_rows)

# Derived metrics table (for the comparative chapter)
mt = [r"\begin{table}[htbp]\centering\footnotesize",
      r"\caption{Derived configuration metrics (class D unless marked E).}\label{tab:metrics}",
      r"\begin{tabular}{@{}lrrrrrr@{}}", r"\toprule",
      r"Vehicle & $L$ [m] & $D$ [m] & $L/D$ [--] & $\lambda_\mathrm{SSO}$ [\%] & $(T/W)_0$ [--] & GLOM est. [t] (E) \\", r"\midrule"]
for k in ORDER:
    v = VEH[k]; m = metrics[k]
    ge = (r"%s--%s" % (fnum(m["glom_est"][0] / 1000, 0), fnum(m["glom_est"][1] / 1000, 0))) if m.get("glom_est") else "--"
    mt.append(r"%s & %s & %s & %s & %s & %s & %s \\" % (
        SHORT[k], fnum(num(v["length"]), 1) or "n.d.", fnum(num(v["diameter"]), 2) or "n.d.",
        f"{m['LD']:.1f}" if m["LD"] else "n.d.", f"{100 * m['lam_sso']:.2f}" if m.get("lam_sso") else "--",
        f"{m['tw']:.2f}" if m.get("tw") else "--", ge))
mt += [r"\bottomrule", r"\end{tabular}",
       r"\par\smallskip\footnotesize $(T/W)_0$ uses the published lift-off (or, where only that is given, vacuum) thrust; LauncherOne value is at drop. Prime uses the quoted 30 kN/engine figure; see Sec.~\ref{sec:prime-analysis}. GLOM estimates assume $(T/W)_0$ = 1.3--1.5.",
       r"\end{table}"]
write("metrics_table.tex", "\n".join(mt) + "\n")

# Economics summary
ec = [r"\begin{table}[htbp]\centering\footnotesize",
      r"\caption{Indicative cost per kilogram = advertised (or reported) price / maximum advertised payload. EUR equivalents use fixed indicative rates (1 USD = 0.86 EUR, 1 GBP = 1.15 EUR).}\label{tab:econ-all}",
      r"\begin{tabularx}{\textwidth}{@{}lr>{\raggedright}p{2.2cm}rrr>{\raggedright\arraybackslash}X@{}}", r"\toprule",
      r"Vehicle & Price [M] & Basis & Payload [kg] & Orbit & Cost/kg & Source \\", r"\midrule"]
for k in ORDER:
    v = VEH[k]; m = metrics[k]; p = v["price"]
    if num(p):
        pf = "sso" if num(v["sso"]) else "leo"
        pl = num(v[pf]); cpk = num(p) / pl
        basis = {"M": "advertised", "S": "secondary / reported"}.get(p["c"], p["c"])
        if k == "vegac": basis = "contract value (ESA)"
        ec.append(r"%s & %s %s & %s & %s & %s & %s %s & %s \\" % (SHORT[k], v["currency"], fnum(num(p) / 1e6, 2), basis, fnum(pl), pf.upper(), v["currency"], fnum(round(cpk, -2)), cites(p, v[pf])))
    elif m.get("cpk_target"):
        ec.append(r"%s & n.d. & target price/kg & %s & %s & EUR %s & %s \\" % (SHORT[k], fnum(num(v["sso"])), "SSO", fnum(m["cpk_target"]), cites(v["price_per_kg"])))
    else:
        ec.append(r"%s & n.d. & -- & -- & -- & n.d. & -- \\" % SHORT[k])
ec += [r"\bottomrule", r"\end{tabularx}", r"\end{table}"]
write("econ_all.tex", "\n".join(ec) + "\n")

# Status table
stt = [r"\begin{table}[htbp]\centering\footnotesize",
       r"\caption{Programme status classification as of 23 November 2026 (vehicle and company assessed separately).}\label{tab:status}",
       r"\begin{tabularx}{\textwidth}{@{}l>{\raggedright}p{2.6cm}>{\raggedright}X>{\raggedright\arraybackslash}p{3.6cm}@{}}", r"\toprule",
       r"Vehicle & Manufacturer (country) & Vehicle status & Company status \\", r"\midrule"]
for k in ORDER:
    v = VEH[k]
    stt.append(r"%s & %s (%s) & %s & %s \\" % (SHORT[k], tex_escape(v["maker"].split(" (")[0]), tex_escape(v["country"]), tex_escape(v["status_vehicle"]), tex_escape(v["status_company"])))
stt += [r"\bottomrule", r"\end{tabularx}", r"\end{table}"]
write("status_table.tex", "\n".join(stt) + "\n")

# ----------------------------------------------------------------------------
# 6. Figures
# ----------------------------------------------------------------------------
def draw_vehicle(ax, x0, k, scale=1.0, label=True, detail=False):
    v = VEH[k]; L = num(v["length"]); D = num(v["diameter"])
    col = GROUP_COLOR[v["group"]]
    sch = SCHEMATIC[k]
    fl = sch["fairing"] or 0.16 * L
    nose = min(0.45 * fl, 1.6 * D)
    body = L - nose
    # body
    ax.add_patch(Rectangle((x0 - D / 2, 0), D, body, facecolor=col, edgecolor="white", lw=0.8, alpha=0.9))
    ax.add_patch(Polygon([[x0 - D / 2, body], [x0 + D / 2, body], [x0, L]], closed=True,
                         facecolor=col, edgecolor="white", lw=0.8, alpha=0.9))
    # fairing boundary
    ax.plot([x0 - D / 2, x0 + D / 2], [L - fl, L - fl], color="white", lw=1.4,
            ls="-" if sch["fairing"] else (0, (2, 2)))
    if sch["stages"]:
        y = 0
        for s in sch["stages"][:-1]:
            y += s
            ax.plot([x0 - D / 2, x0 + D / 2], [y, y], color="white", lw=1.4)
    if label:
        ax.text(x0, -1.2, SHORT[k], ha="center", va="top", fontsize=7, color=INK, rotation=0)
        ax.text(x0, L + 0.6, f"{L:g} m", ha="center", va="bottom", fontsize=6.5, color=INK2)

# 6a lineup
fig, ax = plt.subplots(figsize=(7.2, 5.0))
xs = []
for i, k in enumerate(ORDER):
    x = 3.0 + 4.3 * i
    draw_vehicle(ax, x, k, label=False); xs.append(x)
    L = num(VEH[k]["length"])
    ax.text(x, L + 0.6, f"{L:g}", ha="center", va="bottom", fontsize=6.3, color=INK2)
ax.set_xlim(0, xs[-1] + 3.0); ax.set_ylim(0, 54)
ax.set_aspect("equal")
ax.set_xticks(xs); ax.set_xticklabels([SHORT[k] for k in ORDER], rotation=60, ha="right", fontsize=7)
ax.set_ylabel("Height [m] (all vehicles to the same scale)")
ax.grid(axis="x", visible=False)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=GROUP_COLOR[g], label=GROUP_LABEL[g]) for g in ("eu", "int", "fail")],
          loc="upper right", fontsize=7)
fig.savefig(os.path.join(FIG, "lineup.pdf")); plt.close(fig)

# 6b per-vehicle schematic with dimensions
def schematic(k):
    v = VEH[k]; L = num(v["length"]); D = num(v["diameter"]); sch = SCHEMATIC[k]
    fig, ax = plt.subplots(figsize=(2.7, 4.5))
    draw_vehicle(ax, 0, k, label=False)
    ax.set_aspect("equal"); ax.axis("off")
    w = max(D, 1.2)
    # length dimension
    ax.annotate("", xy=(-w * 1.6, 0), xytext=(-w * 1.6, L), arrowprops=dict(arrowstyle="<->", color=INK2, lw=0.8))
    ax.text(-w * 1.75, L / 2, f"L = {L:g} m", rotation=90, ha="right", va="center", fontsize=8.5, color=INK)
    ax.annotate("", xy=(-D / 2, -0.9), xytext=(D / 2, -0.9), arrowprops=dict(arrowstyle="<->", color=INK2, lw=0.8))
    ax.text(0, -1.4, f"D = {D:g} m", ha="center", va="top", fontsize=8.5, color=INK)
    # stage labels (with simple vertical de-overlap and leader lines)
    st = v["stages"]
    fl = sch["fairing"] or 0.16 * L
    items = []  # (y_target, text)
    if sch["stages"]:
        y = 0
        for i, s in enumerate(sch["stages"]):
            ss = st[i] if i < len(st) else None
            txt = ss["name"] if ss else f"S{i+1}"
            if ss and ss["n_eng"]["v"] is not None:
                txt += f"\n{ss['n_eng']['v']}x {ss['engine']['v'].split(' (')[0]}"
            items.append((y + s / 2, txt + f"\n{s:g} m"))
            y += s
    else:
        lines = []
        for s in st:
            e = s["engine"]["v"]; n = s["n_eng"]["v"]
            lines.append(f"{s['name']}: " + (f"{n}x " if n is not None else "") + (e.split(' (')[0] if e else "engine n.d."))
        items.append(((L - fl) / 2, "\n".join(lines) + "\n(stage boundaries\nnot disclosed)"))
    items.append((L - fl / 2, "Fairing" + (f"\n{fl:g} m" if sch["fairing"] else "\n(length n.d.)")))
    items.sort(key=lambda t: t[0])
    gap = 0.20 * L
    ys = []
    for yt, _ in items:
        yy = yt if not ys else max(yt, ys[-1] + gap)
        ys.append(yy)
    over = ys[-1] - (L + 2.5)
    if over > 0:
        ys = [y - over for y in ys]
        for j in range(len(ys) - 2, -1, -1):
            ys[j] = min(ys[j], ys[j + 1] - gap)
    xl = w * 1.2
    for (yt, txt), yy in zip(items, ys):
        if abs(yy - yt) > 0.02 * L:
            ax.plot([D / 2, xl * 0.92], [yt, yy], color=INK2, lw=0.5)
        ax.text(xl, yy, txt, ha="left", va="center", fontsize=7.8, color=INK)
    prop = v["propellants"]["v"]
    ytop = max(L, max(ys) + 0.06 * L) + 0.04 * L
    ax.text(0, ytop, v["name"], ha="center", va="bottom", fontsize=10, weight="bold", color=INK)
    ax.set_xlim(-w * 3.2, w * 6.5); ax.set_ylim(-3.0, ytop + 0.1 * L)
    fig.savefig(os.path.join(FIG, f"{k}_schematic.pdf")); plt.close(fig)

for k in ORDER:
    schematic(k)

# 6c payload vs GLOM
fig, ax = plt.subplots(figsize=(6.4, 3.9))
for lam in (0.005, 0.01, 0.02):
    xx = np.array([8e3, 3e5]); ax.plot(xx, lam * xx, color=AXIS, lw=0.8, ls=(0, (3, 3)), zorder=1)
    xl = 1.2e5
    ax.text(xl, lam * xl * 1.12, f"λ = {100*lam:g} %", fontsize=6.5, color=INK2, ha="left")
pts = []
for k in ORDER:
    v = VEH[k]; m0 = num(v["glom"]); est = False
    if not m0 and metrics[k].get("glom_est"):
        m0 = sum(metrics[k]["glom_est"]) / 2; est = True
    pl = num(v["sso"]) or num(v["leo"])
    if not (m0 and pl):
        continue
    col = GROUP_COLOR[v["group"]]
    if est:
        lo, hi = metrics[k]["glom_est"]
        ax.plot([lo, hi], [pl, pl], color=col, lw=2, alpha=0.5, zorder=2)
        ax.scatter([m0], [pl], s=36, facecolor="white", edgecolor=col, linewidth=1.6, zorder=3)
    else:
        ax.scatter([m0], [pl], s=40, color=col, edgecolor="white", linewidth=1.5, zorder=3)
    tag = SHORT[k] + ("" if num(v["sso"]) else " (LEO)")
    off = {"spectrum": (-8, 6), "alpha": (-6, -10), "miura5": (6, -2), "rfaone": (6, 2), "vegac": (-6, 6),
           "maia": (-4, -11), "skyrora": (6, -2), "sl1": (6, 3)}.get(k, (5, 3))
    ha = "right" if off[0] < 0 else "left"
    ax.annotate(tag, (m0, pl), xytext=off, textcoords="offset points", fontsize=6.8, color=INK, ha=ha)
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_xlabel("Lift-off mass [kg]  (open markers: estimated from thrust, bar = T/W 1.5–1.3)")
ax.set_ylabel("Max. advertised SSO payload [kg]")
ax.set_xlim(8e3, 3.2e5); ax.set_ylim(15, 4000)
for g in ("eu", "int", "fail"):
    ax.scatter([], [], color=GROUP_COLOR[g], label=GROUP_LABEL[g], s=30)
ax.legend(loc="upper left", fontsize=7)
ax.set_title("Advertised payload versus lift-off mass")
fig.savefig(os.path.join(FIG, "payload_glom.pdf")); plt.close(fig)

# 6d cost per kg
items = []
for k in ORDER:
    v = VEH[k]; m = metrics[k]
    if m.get("cpk_sso") or m.get("cpk_leo"):
        val = m.get("cpk_sso") or m.get("cpk_leo")
        items.append((SHORT[k] + (" (SSO)" if m.get("cpk_sso") else " (LEO)"), to_eur(val, v["currency"]), v["group"], v["price"]["c"]))
    elif m.get("cpk_target"):
        items.append((SHORT[k] + " (target)", m["cpk_target"], v["group"], "S"))
items.sort(key=lambda t: t[1])
fig, ax = plt.subplots(figsize=(6.4, 3.4))
y = np.arange(len(items))
ax.barh(y, [t[1] / 1000 for t in items], color=[GROUP_COLOR[t[2]] for t in items], height=0.62, edgecolor="white", linewidth=2)
for i, t in enumerate(items):
    ax.text(t[1] / 1000 + 0.6, i, f"{t[1]/1000:,.1f} k€/kg  [{t[3]}]", va="center", fontsize=6.8, color=INK)
ax.set_yticks(y); ax.set_yticklabels([t[0] for t in items], fontsize=7.5)
ax.set_xlabel("Indicative price per kg of maximum advertised payload [thousand EUR/kg]")
ax.grid(axis="y", visible=False); ax.set_xlim(0, max(t[1] for t in items) / 1000 * 1.25)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=GROUP_COLOR[g], label=GROUP_LABEL[g]) for g in ("eu", "int", "fail")], loc="lower right", fontsize=7)
ax.set_title("Indicative launch price per kilogram (advertised price ÷ max. payload)")
fig.savefig(os.path.join(FIG, "cost_per_kg.pdf")); plt.close(fig)

# 6e implied eps
ks = ["electron", "alpha", "launcherone", "miura5", "prime", "skyrora", "sl1"]
fig, ax = plt.subplots(figsize=(6.4, 3.0))
for i, k in enumerate(ks):
    r = eps_res[k]; col = GROUP_COLOR[VEH[k]["group"]]
    ax.plot([r["lo"], r["hi"]], [i, i], color=col, lw=3, alpha=0.45, solid_capstyle="round")
    ax.scatter([r["e"]], [i], color=col, s=40, zorder=3, edgecolor="white", linewidth=1.5)
    ax.text(r["hi"] + 0.004, i, f"ε = {r['e']:.3f}", va="center", fontsize=6.8, color=INK)
ax.axvspan(0.073, 0.119, color=GRID, alpha=0.6, zorder=0)
ax.text(0.096, len(ks) - 0.45, "Vega-C flown solid stages", ha="center", fontsize=6.5, color=INK2)
ax.set_yticks(range(len(ks))); ax.set_yticklabels([SHORT[k] for k in ks])
ax.set_xlabel("Implied common structural coefficient ε (lower = lighter structure required)")
ax.grid(axis="y", visible=False); ax.invert_yaxis()
ax.set_title("Structural efficiency implied by published mass and payload (estimate)")
fig.savefig(os.path.join(FIG, "implied_eps.pdf")); plt.close(fig)

# 6f schedule slip
fig, ax = plt.subplots(figsize=(6.4, 3.0))
keys = list(SLIP.keys())
for i, k in enumerate(keys):
    a, b, flown, _ = SLIP[k]
    col = GROUP_COLOR[VEH[k]["group"]]
    if b is None:
        ax.plot([a, 2026.15], [i, i], color=col, lw=3, alpha=0.6)
        ax.scatter([a], [i], color=col, s=30, zorder=3)
        ax.text(2026.3, i, "cancelled Feb 2026 (never flew)", va="center", fontsize=6.8, color=INK)
    else:
        ax.plot([a, b], [i, i], color=col, lw=3, alpha=0.6)
        ax.scatter([a], [i], color=col, s=30, zorder=3)
        ax.scatter([b], [i], s=42, zorder=3, facecolor=col if flown else "white", edgecolor=col, linewidth=1.6)
        ax.text(b + 0.15, i, ("first flight " if flown else "current target ") + str(b) + f"  (+{b - a} yr)", va="center", fontsize=6.8, color=INK)
ax.axvline(2026.9, color=AXIS, lw=0.8, ls=(0, (2, 2)))
ax.text(2026.95, -0.62, "cut-off Nov 2026", fontsize=6, color=INK2, ha="left", va="bottom")
ax.set_yticks(range(len(keys))); ax.set_yticklabels([SHORT[k] for k in keys]); ax.set_ylim(len(keys) - 0.5, -1.0)
ax.set_xlim(2020.5, 2033); ax.set_xlabel("Year (dot: earliest public first-flight target; ring: current target; filled ring: flown)")
ax.grid(axis="y", visible=False)
ax.set_title("Schedule slip of European small-launch programmes")
fig.savefig(os.path.join(FIG, "schedule_slip.pdf")); plt.close(fig)

# 6g launch record
flown = [k for k in ORDER if VEH[k]["launches"] > 0 and k != "electron"]
fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.8), gridspec_kw=dict(width_ratios=[3, 1.1]))
ax = axes[0]
for i, k in enumerate(flown):
    v = VEH[k]; s, p, n = v["successes"], v["partial"], v["launches"]; f = n - s - p
    ax.barh(i, s, color=C_GOOD, edgecolor="white", linewidth=2, height=0.6)
    ax.barh(i, p, left=s, color=C_WARN, edgecolor="white", linewidth=2, height=0.6)
    ax.barh(i, f, left=s + p, color=C_CRIT, edgecolor="white", linewidth=2, height=0.6)
    ax.text(n + 0.15, i, f"{s}/{n}", va="center", fontsize=7, color=INK)
ax.set_yticks(range(len(flown))); ax.set_yticklabels([SHORT[k] for k in flown]); ax.invert_yaxis()
ax.set_xlabel("Orbital launch attempts"); ax.grid(axis="y", visible=False)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=C_GOOD, label="success"), Patch(color=C_WARN, label="partial failure"), Patch(color=C_CRIT, label="failure")], fontsize=6.8, loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=3); ax.set_title("Flight record (excl. Electron)")
ax = axes[1]
ax.bar([0], [96], color=C_GOOD, width=0.6, edgecolor="white", linewidth=2)
ax.bar([0], [4], bottom=[96], color=C_CRIT, width=0.6, edgecolor="white", linewidth=2)
ax.text(0, 102, "96/100", ha="center", fontsize=7, color=INK)
ax.set_xticks([0]); ax.set_xticklabels(["Electron\n(incl. 9 HASTE)"]); ax.set_ylim(0, 112)
ax.grid(axis="x", visible=False); ax.set_title("Electron")
fig.tight_layout()
fig.savefig(os.path.join(FIG, "launch_record.pdf")); plt.close(fig)

# 6h fineness ratio
fig, ax = plt.subplots(figsize=(6.4, 3.0))
it = sorted([(SHORT[k], metrics[k]["LD"], VEH[k]["group"]) for k in ORDER if metrics[k]["LD"]], key=lambda t: t[1])
ax.bar(range(len(it)), [t[1] for t in it], color=[GROUP_COLOR[t[2]] for t in it], edgecolor="white", linewidth=2, width=0.7)
for i, t in enumerate(it):
    ax.text(i, t[1] + 0.3, f"{t[1]:.1f}", ha="center", fontsize=6.5, color=INK)
ax.set_xticks(range(len(it))); ax.set_xticklabels([t[0] for t in it], rotation=40, ha="right", fontsize=7)
ax.set_ylabel("Fineness ratio L/D [–]"); ax.grid(axis="x", visible=False)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=GROUP_COLOR[g], label=GROUP_LABEL[g]) for g in ("eu", "int", "fail")], fontsize=7, loc="upper left")
ax.set_title("Overall fineness ratio")
fig.savefig(os.path.join(FIG, "fineness.pdf")); plt.close(fig)

print("Vega-C reconstructed dv = %.0f m/s" % veg_dv)
for k, r in eps_res.items():
    print(k, "eps=%.3f (%.3f-%.3f) lam=%.4f" % (r["e"], r["lo"] or 0, r["hi"] or 0, r["lam"]))
for k, p in plaus.items():
    print(k, "GLOM %.0f-%.0f t, pl %.0f-%.0f kg vs adv %s" % (p["m0"][0] / 1e3, p["m0"][1] / 1e3, p["pl"][0], p["pl"][1], p["adv"]))
for k in ORDER:
    m = metrics[k]
    print(k, {kk: (round(vv, 3) if isinstance(vv, float) else vv) for kk, vv in m.items()})

# ----------------------------------------------------------------------------
# 7. Key-facts tables (chapter openers)
# ----------------------------------------------------------------------------
for k in ORDER:
    v = VEH[k]
    rows = [("Official name", tex_escape(v["name"])), ("Manufacturer", tex_escape(v["maker"])),
            ("Country", tex_escape(v["country"])), ("Vehicle status", tex_escape(v["status_vehicle"])),
            ("Company status", tex_escape(v["status_company"])),
            ("Stages", cell(v["stages_n"])), ("Propellants", tex_escape(v["propellants"]["v"])),
            ("Length / diameter", f"{fnum(num(v['length']), 2)} m / {fnum(num(v['diameter']), 2)} m"),
            ("First launch", tex_escape(v["first_launch"]["v"])),
            ("Launch site(s)", tex_escape(v["site"]))]
    out = [r"\begin{tabularx}{\linewidth}{@{}>{\bfseries\raggedright}p{2.35cm}>{\raggedright\arraybackslash}X@{}}", r"\toprule"]
    for a, b in rows:
        out.append(f"{a} & {b} " + r"\\")
    out += [r"\bottomrule", r"\end{tabularx}"]
    write(f"{k}_facts.tex", "\n".join(out) + "\n")
print("facts written")
