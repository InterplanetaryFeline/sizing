#!/usr/bin/env python3
"""
Proposed technical requirements for a hypothetical European micro-launcher.
Single source for: the LaTeX requirements matrix in the report, the standalone
requirements form (LaTeX/PDF) and the editable XLSX form.
Run from report root: python3 scripts/requirements.py
"""
import os, sys, csv
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GEN = os.path.join(ROOT, "generated"); STD = os.path.join(ROOT, "standalone")
G0 = 9.80665

# --------------------------------------------------------------------------
# Sizing sensitivity used to justify vehicle/propulsion targets
# --------------------------------------------------------------------------
def opt_lambda(dv, isp, eps):
    c = np.array(isp) * G0; e = np.array(eps)
    f = lambda eta: np.sum(c * np.log((eta * c - 1) / (eta * c * e))) - dv
    lo = 1 / c.min() + 1e-12; hi = lo * 2
    while True:
        n = (hi * c - 1) / (hi * c * e)
        if np.all(n > 1) and f(hi) > 0: break
        hi *= 2
    for _ in range(200):
        mid = (lo + hi) / 2
        n = (mid * c - 1) / (mid * c * e)
        if np.any(n <= 1) or f(mid) < 0: lo = mid
        else: hi = mid
    n = (hi * c - 1) / (hi * c * e)
    pi = (1 - e * n) / ((1 - e) * n)
    return float(np.prod(pi)), n

cases = []
for isp in ([300, 335], [305, 340], [310, 345]):
    for eps in ([0.09, 0.12], [0.08, 0.11], [0.10, 0.14]):
        lam, n = opt_lambda(9600, isp, eps)
        cases.append((isp, eps, lam, 500 / lam / 1000))
sens = [r"\begin{table}[htbp]\centering\footnotesize",
        r"\caption{Sizing sensitivity for the requirements baseline: optimal two-stage payload fraction for a 9.6\,km/s ideal $\Delta v$ (500\,km SSO) and the lift-off mass needed for 500\,kg (class E).}\label{tab:req-sens}",
        r"\begin{tabular}{@{}cccrr@{}}", r"\toprule",
        r"$I_\mathrm{sp}$ S1 eff.\ / S2 vac [s] & $\varepsilon_1$ & $\varepsilon_2$ & $\lambda$ [\%] & $m_0$ for 500 kg [t] \\", r"\midrule"]
for isp, eps, lam, m0 in cases:
    sens.append(r"%d / %d & %.2f & %.2f & %.2f & %.1f \\" % (isp[0], isp[1], eps[0], eps[1], 100 * lam, m0))
sens += [r"\bottomrule", r"\end{tabular}",
         r"\par\smallskip\footnotesize Electron (1.54\,\%) and Alpha (1.16\,\%) bracket the payload fractions in this table; the margin-carrying row (305/340\,s, 0.10/0.14; 39.4\,t) sizes the 40\,t GLOM target of VEH-04, while the stretch row (0.09/0.12; 30.8\,t) corresponds to meeting VEH-09/VEH-10.",
         r"\end{table}"]
open(os.path.join(GEN, "req_sensitivity.tex"), "w").write("\n".join(sens) + "\n")
BASE = [c for c in cases if c[0] == [305, 340] and c[1] == [0.10, 0.14]][0]
STRETCH = [c for c in cases if c[0] == [305, 340] and c[1] == [0.09, 0.12]][0]

# --------------------------------------------------------------------------
# Requirements (ID, description, parameter, target, unit, priority,
#               rationale, verification, basis)
#   basis: D = derived from the comparative analysis,
#          A = assumption, P = preliminary engineering target
# --------------------------------------------------------------------------
R = []
def req(i, desc, par, tgt, unit, pri, rat, ver, basis):
    R.append(dict(id=i, desc=desc, par=par, tgt=tgt, unit=unit, pri=pri, rat=rat, ver=ver, basis=basis))

CAT = {"MIS": "Mission requirements", "VEH": "Vehicle requirements", "PRO": "Propulsion requirements",
       "OPS": "Operational requirements", "ECO": "Economic requirements", "REL": "Reliability and safety requirements"}

# Mission
req("MIS-01", "Deliver a single payload to the reference orbit", "Payload mass, 500 km circular SSO", "400", "kg", "Must",
    "Surviving European programmes sit at 540-1,500 kg; programmes below 200 kg (Prime, Rocket 3.3) failed commercially; Electron (200 kg) needed 100 flights of cadence (Ch. 21).", "A, then D (flight)", "D")
req("MIS-02", "Growth target for the reference payload", "Payload mass, 500 km circular SSO", "500", "kg", "Should",
    "Matches MIURA 5 class (540 kg) and the sensitivity baseline (Table req-sens); keeps GLOM near 40 t.", "A, D", "D")
req("MIS-03", "Reference orbit definition", "Altitude / inclination", "500 / 97.4", "km / deg", "Must",
    "Most common small-satellite destination; matches Vega-C and Electron reference cases enabling like-for-like comparison.", "A", "D")
req("MIS-04", "Orbit range served", "Circular SSO altitude range", "400-1,000", "km", "Must",
    "Skyrora XL and RFA ONE advertise up to 1,000-2,000 km; Earth-observation demand spans 400-800 km.", "A", "P")
req("MIS-05", "Inclination coverage from primary site", "Inclination range", "87-110", "deg", "Must",
    "Andøya supports 87.4-108 deg; SSO at 500-1,000 km lies in 97-100 deg.", "A", "D")
req("MIS-06", "Low/mid-inclination capability", "Inclination", "40-70 (from a second site)", "deg", "Could",
    "Constellation customers (MIURA 5, Spectrum Nova Scotia) need mid-inclinations not reachable efficiently from 60-70 deg N.", "A", "D")
req("MIS-07", "Primary launch-site latitude", "Site latitude", ">= 58 N (northern Europe)", "deg", "Should",
    "European newcomers operate from Andøya (69.3 N) and SaxaVord (60.8 N); high-latitude sites favour polar/SSO.", "R", "D")
req("MIS-08", "Multi-orbit deployment", "Upper-stage (or kick-stage) ignitions", ">= 3", "--", "Should",
    "Insertion, circularisation and disposal; demonstrated by Spectrum F2 and Electron's kick stage.", "T, D", "D")
req("MIS-09", "Minimum restart capability", "Ignitions", ">= 2", "--", "Must",
    "Required for SSO circularisation and upper-stage disposal (REL-07).", "T, D", "D")
req("MIS-10", "Launch frequency (operations year 2)", "Launches per year", ">= 6", "1/yr", "Should",
    "Rocket Lab's cost base was carried by 14-21 launches per year; Virgin Orbit failed at ~2 per year.", "D", "P")
req("MIS-11", "Launch frequency (operations year 4)", "Launches per year", ">= 12", "1/yr", "Should",
    "Spectrum targets 40 vehicles/yr production; Latitude 50 launches/yr by 2030; 12/yr is a conservative intermediate.", "D", "P")
req("MIS-12", "Payload classes supported", "Configurations", "Dedicated 100-500 kg; rideshare CubeSat to 200 kg", "--", "Must",
    "All operational vehicles offer both modes; rideshare fills unused capacity.", "R, D", "D")

# Vehicle
req("VEH-01", "Number of main stages", "Stages", "2 (+ optional kick stage)", "--", "Must",
    "Twelve of fifteen vehicles use two main stages; third stages appear only with lower-Isp propellants or for OTV services.", "R", "D")
req("VEH-02", "Maximum vehicle diameter", "Outer diameter", "<= 2.2", "m", "Must",
    "2.0-2.2 m cluster (Spectrum, RFA ONE, MIURA 5, Latitude, SL1, Skyrora XL, Alpha) - road-transportable, fairing for 500-1,000 kg.", "I", "D")
req("VEH-03", "Maximum vehicle length", "Overall length", "<= 30", "m", "Should",
    "Keeps L/D <= 15 (median of set ~14); MIURA 5 (35.7 m, L/D 18) shows the cost of slenderness.", "I", "D")
req("VEH-04", "Maximum lift-off mass", "GLOM", "<= 45 (target 40)", "t", "Must",
    "500 kg / lambda: sizing with margin (eps 0.10/0.14) gives %.1f t, stretch structure (eps 0.09/0.12) %.1f t (Table req-sens); 45 t covers lambda >= 1.1 %% (Alpha level)." % (BASE[3], STRETCH[3]), "A, I (weighing)", "D")
req("VEH-05", "Payload fraction to reference orbit", "Payload mass / lift-off mass", ">= 1.1 (target 1.25)", "%", "Must",
    "Electron 1.54 %, Alpha 1.16 %, MIURA 5 0.78 %, Skyrora XL 0.56 % (Table eps-summary).", "A", "D")
req("VEH-06", "Fairing usable diameter", "Usable diameter", ">= 1.8", "m", "Must",
    "Electron's 1.07 m usable diameter is its most frequent constraint; Alpha 2.2 m and Spectrum ~2 m external.", "I", "D")
req("VEH-07", "Fairing usable height", "Usable cylindrical + conical height", ">= 3.5", "m", "Should",
    "Latitude 2.3-3.2 m (300 kg class); Alpha 5 m and Spectrum ~6 m (1 t class).", "I", "D")
req("VEH-08", "Fairing usable volume", "Volume", ">= 8", "m3", "Should",
    "Between Latitude (4.1 m3) and Spectrum (~13 m3).", "A, I", "P")
req("VEH-09", "Stage-1 structural coefficient", "S1 structural coefficient eps_1", "<= 0.09", "--", "Should",
    "Vega-C Z40 0.105 and P120C 0.073; implied common eps 0.10 (Alpha) to 0.12 (Electron).", "A, I", "P")
req("VEH-10", "Stage-2 structural coefficient", "S2 structural coefficient eps_2", "<= 0.12", "--", "Should",
    "Upper stages carry relatively more avionics and residuals; Vega-C Z9 0.119.", "A, I", "P")
req("VEH-11", "Stage propellant mass fractions", "Propellant mass / stage mass (S1 / S2)", ">= 0.91 / >= 0.88", "--", "Should",
    "Equivalent to VEH-09/10.", "A, I", "P")
req("VEH-12", "Payload interface", "Standard adapter", "937 mm clamp band (single); 8/15/24 in ports (rideshare)", "--", "Should",
    "Alpha bolt pattern compatible with 937 mm adapters; RFA offers 8/15/24 in rideshare ports.", "I, T", "D")

# Propulsion
req("PRO-01", "Propellant combination", "Oxidiser / fuel", "LOX / hydrocarbon (RP-1 baseline; propane or methane permitted)", "--", "Should",
    "Eight of fifteen vehicles use LOX/RP-1; only Vega-C and Electron have long records. Alternatives showed no decisive system-level advantage in this class.", "R", "D")
req("PRO-02", "Stage-1 effective specific impulse", "Isp, trajectory-averaged", ">= 305 (SL >= 290)", "s", "Must",
    "Baseline sizing row; Electron 311 s SL; RFA claims 325 s SL.", "T (hot fire)", "D")
req("PRO-03", "Stage-2 vacuum specific impulse", "Isp, vacuum", ">= 340", "s", "Must",
    "Electron 343 s, RFA 350 s (claimed), Alpha 322 s; each +5 s raises lambda measurably (Table req-sens).", "T", "D")
req("PRO-04", "Stage-1 engine count", "Engines", "5-9 identical", "--", "Should",
    "Nine engines is the modal choice; common engine multiplies production rate and reduces designs; Alpha's 4-engine stage was lost to one engine-out.", "R", "D")
req("PRO-05", "Common engine across stages", "Upper-stage engine", "Vacuum variant of S1 engine", "--", "Should",
    "Used by all five nine-engine vehicles and by Latitude, MIURA 5, Maia.", "R", "D")
req("PRO-06", "Lift-off thrust-to-weight ratio", "Lift-off thrust-to-weight ratio", "1.3-1.5 (min. 1.25)", "--", "Must",
    "Electron 1.49, MIURA 5 1.40; Skyrora XL 1.15 and Prime's published data (1.02) are too low.", "A, T", "D")
req("PRO-07", "Total lift-off thrust", "Lift-off thrust at GLOM 40 t", "510-590", "kN", "Must",
    "From PRO-06 and VEH-04 (40 t x g0 x 1.3-1.5).", "T", "D")
req("PRO-08", "Upper-stage ignition T/W", "T/W at S2 ignition", ">= 0.7", "--", "Should",
    "Limits gravity losses; MIURA 5 estimate ~0.75.", "A", "P")
req("PRO-09", "Restart reliability", "Successful relights in qualification", ">= 20 consecutive", "--", "Must",
    "Alpha F4 lost its mission on a failed relight.", "T", "P")
req("PRO-10", "Reusability provisions", "S1 recovery", "Design provisions only (no baseline recovery)", "--", "Could",
    "Electron recovered 9 stages but reflew none; Latitude finds reuse uneconomic below ~3-4 t; MIURA 5 pays ~0.4 pp of lambda.", "R", "D")
req("PRO-11", "Engine-out capability", "S1 engine-out after T+60 s", "Mission success with 1 engine out", "--", "Could",
    "Plausible with 9 engines; not demonstrated by any vehicle in the set.", "A, T", "P")

# Operations
req("OPS-01", "Launch-site compatibility", "Pad interface", "Compatible with Andøya/SaxaVord-class commercial pads", "--", "Must",
    "European newcomers rely on these sites; pad availability delayed Skyrora and Orbex.", "R, I", "D")
req("OPS-02", "Aft-end / pad thermal environment", "Plume recirculation analysis and test", "Verified before first hot fire", "--", "Must",
    "RS1 DEMO-1 lost to aft-cavity fire from launch-mount recirculation; RS1 DEMO-2 pad fire.", "A, T", "D")
req("OPS-03", "Ground support equipment", "GSE transport", "Containerised (ISO), road-transportable", "--", "Should",
    "RS1 containerised GSE concept; island spaceports require road/sea transport.", "I", "D")
req("OPS-04", "Vehicle integration", "Integration mode", "Horizontal; vertical payload encapsulation optional", "--", "Should",
    "Maia horizontal integration in a hangar; keeps pad simple.", "I, D", "P")
req("OPS-05", "Launch campaign duration", "Vehicle arrival to launch", "<= 14", "days", "Should",
    "Preliminary target supporting MIS-11 cadence.", "D", "P")
req("OPS-06", "Pad turnaround", "Launch to next-launch readiness", "<= 7", "days", "Could",
    "Needed for >= 24 launches/yr from one pad.", "D", "P")
req("OPS-07", "Late payload access", "Payload mate before launch", "<= 72", "h", "Should",
    "Customer requirement for battery charging/propellant loading; preliminary.", "D", "A")
req("OPS-08", "Stage transportability", "Max. stage length on road", "<= 20", "m", "Must",
    "With VEH-02, allows standard special-transport road moves (Spectrum, RFA ship from southern Germany).", "I", "P")
req("OPS-09", "Propellant logistics", "Cryogen supply", "LOX and fuel deliverable by road to remote sites", "--", "Must",
    "SaxaVord and Andøya are island sites; HTP/storables avoid this but cost performance.", "R", "D")
req("OPS-10", "Payload User's Guide", "Public availability", "Published openly before first flight", "--", "Should",
    "Most European newcomers release guides only on request; transparency supports customer and investor confidence (Orbex lesson).", "I", "P")

# Economics
req("ECO-01", "Development cost to first orbital flight", "Non-recurring cost", "<= 250", "EUR M", "Should",
    "Electron project cost ~USD 100 M; Vega-C EUR 395 M; Orbex failed after GBP 138.5 M; Skyrora estimates USD 130 M needed. Preliminary.", "R (cost audit)", "P")
req("ECO-02", "Dedicated launch price", "Price, full dedicated launch", "<= 6", "EUR M", "Should",
    "Below Electron (USD 7.5-8.4 M) and Alpha (USD 15 M) per launch.", "R", "P")
req("ECO-03", "Price per kg at reference orbit", "Price / 500 kg", "<= 12,000 (Must <= 15,000)", "EUR/kg", "Must",
    "Flown dedicated vehicles: EUR 20-32 k/kg; Spectrum target EUR 10 k/kg.", "A", "D")
req("ECO-04", "Manufacturing approach", "Engines / structures", "Additive-manufactured engines; automated composite or welded Al/steel tanks", "--", "Should",
    "AM engines universal among newcomers; Electron/Alpha automated composites; RFA steel, Latitude Al.", "R, I", "D")
req("ECO-05", "Production rate (operations year 3)", "Vehicles per year", ">= 12", "1/yr", "Should",
    "Supports MIS-11; engines >= 100/yr with 9+1 configuration.", "D", "P")
req("ECO-06", "Recurring cost share of propulsion", "Engine cost / vehicle cost", "<= 40", "%", "Could",
    "Preliminary target; common engine and AM to reduce engine cost.", "A", "A")

# Reliability & safety
req("REL-01", "Design reliability", "Predicted mission success probability", ">= 0.97", "--", "Must",
    "Electron's demonstrated 96 % over 100 launches sets the commercial benchmark.", "A (reliability model)", "D")
req("REL-02", "Demonstrated reliability, first 10 flights", "Successes / attempts", ">= 8/10", "--", "Should",
    "Alpha 3/7 and Rocket 3.3 2/7 show the commercial cost of low early reliability.", "D", "D")
req("REL-03", "Avionics redundancy", "Flight computers / IMUs", "Dual-redundant (fail-operational)", "--", "Must",
    "Electron F20 (igniter fault corrupting TVC data) and Astra LV0008 (wiring/TVC software) show single-string avionics risk.", "A, T", "D")
req("REL-04", "Fluid-system fault tolerance", "Vent / pressurisation valves", "Single-fault tolerant; no attitude-critical venting", "--", "Must",
    "Spectrum F1 (vent valve), LauncherOne F1 (LOX line), Eris TF1 (oxidiser pump): fluid faults dominate first-flight failures.", "A, T", "D")
req("REL-05", "Flight termination system", "FTS type", "Autonomous FTS, dual-redundant", "--", "Must",
    "Range-safety requirement at European sites; Spectrum F1 terminated nominally.", "T, R", "A")
req("REL-06", "High-voltage electrical design", "Partial-discharge / arc testing in vacuum", "Qualified for all > 100 V systems", "--", "Must",
    "Electron F41: arc in motor power system at 420-508 V near vacuum.", "T", "D")
req("REL-07", "Upper-stage disposal", "Post-mission disposal time", "<= 5 (controlled de-orbit preferred)", "years", "Must",
    "Aligned with current ESA space-debris mitigation policy (to be verified against the applicable edition); Spectrum F2 performed a deorbit burn.", "A, D", "A")
req("REL-08", "Ground-test acceptance", "Stage acceptance hot fire", "Full-duration before each flight", "--", "Should",
    "Ground losses at RFA (2024), Firefly (2025), ABL (2024) occurred in such tests - better on the stand than in flight.", "T", "D")
req("REL-09", "Contamination control", "Fluid-system cleanliness", "Verified per stage before hot fire", "--", "Must",
    "Firefly Sep 2025 stage loss traced to hydrocarbon contamination.", "I, T", "D")
req("REL-10", "Regulatory compliance", "Licences", "UK SIA 2018 / Norwegian / French LOS as applicable", "--", "Must",
    "RFA (CAA, max 10 launches/yr) and Isar (NCAA) licence precedents.", "R", "D")
req("REL-11", "Casualty risk", "Expected casualties per launch / re-entry", "<= 1e-4 or national limit", "--", "Must",
    "Commonly applied threshold; confirm with the licensing authority (assumption).", "A", "A")

# --------------------------------------------------------------------------
# Writers
# --------------------------------------------------------------------------
def esc(s):
    return (s.replace("%", r"\%").replace("&", r"\&").replace("_", r"\_").replace(">=", r"$\geq$")
             .replace("<=", r"$\leq$").replace("eps\\_1", "@E1@").replace("eps\\_2", "@E2@").replace("eps", "@E@").replace("lambda", r"$\lambda$")
             .replace("m3", r"m$^3$").replace("1e-4", r"$10^{-4}$").replace("x g0 x", r"$\times g_0 \times$")
             .replace("/", r"/\allowbreak{}")
             .replace("@E1@", r"$\varepsilon_1$").replace("@E2@", r"$\varepsilon_2$").replace("@E@", r"$\varepsilon$")
             .replace("Table req-sens", r"Table~\ref{tab:req-sens}").replace("Table eps-summary", r"Table~\ref{tab:eps-summary}"))

def matrix_tex(standalone=False):
    lines = [r"\footnotesize", r"\renewcommand{\arraystretch}{1.15}", r"\setlength{\tabcolsep}{4pt}",
             r"\begin{longtable}{@{}>{\raggedright}p{1.25cm}>{\raggedright}p{3.7cm}>{\raggedright}p{2.9cm}>{\raggedright}p{2.9cm}>{\raggedright}p{1.0cm}>{\raggedright}p{1.1cm}>{\raggedright}p{7.2cm}>{\raggedright\arraybackslash}p{1.3cm}@{}}",
             r"\caption{Proposed technical requirements matrix (basis: D = derived from comparative analysis, P = preliminary engineering target, A = assumption).}\label{tab:req-matrix}\\",
             r"\toprule", r"ID & Requirement & Parameter & Target value & Unit & Priority & Rationale [basis] & Verif. \\", r"\midrule", r"\endfirsthead",
             r"\toprule", r"ID & Requirement & Parameter & Target value & Unit & Priority & Rationale [basis] & Verif. \\", r"\midrule", r"\endhead",
             r"\midrule \multicolumn{8}{r}{\textit{continued on next page}} \\", r"\endfoot", r"\bottomrule", r"\endlastfoot"]
    cur = None
    for r in R:
        c = r["id"].split("-")[0]
        if c != cur:
            lines.append(r"\multicolumn{8}{@{}l}{\cellcolor{docbg}\textbf{%s}} \\" % CAT[c])
            cur = c
        pri = {"Must": r"\textbf{Must}", "Should": "Should", "Could": r"\textit{Could}"}[r["pri"]]
        lines.append(r"%s & %s & %s & %s & %s & %s & %s [%s] & %s \\" % (
            r["id"], esc(r["desc"]), esc(r["par"]), esc(r["tgt"]), esc(r["unit"]), pri, esc(r["rat"]), r["basis"], r["ver"]))
    lines.append(r"\end{longtable}")
    lines.append(r"\par\footnotesize Verification methods: A = analysis, T = test, I = inspection, D = demonstration (flight/operations), R = review of design or documentation.")
    return "\n".join(lines) + "\n"

open(os.path.join(GEN, "req_matrix.tex"), "w").write(matrix_tex())

# Standalone form (compiles on its own)
std = r"""\documentclass[10pt,a4paper,landscape]{article}
\usepackage[T1]{fontenc}\usepackage[utf8]{inputenc}\usepackage{lmodern}\usepackage[scaled=0.92]{helvet}
\usepackage[a4paper,landscape,margin=14mm]{geometry}
\usepackage{booktabs,longtable,array}\usepackage[table]{xcolor}\usepackage{amsmath}\usepackage{caption}\usepackage{fancyhdr}
\definecolor{docbg}{HTML}{EEF4FC}\definecolor{brand}{HTML}{184F95}
\pagestyle{fancy}\fancyhf{}\fancyhead[L]{\small\sffamily Proposed Technical Requirements Form -- Hypothetical European Micro-Launcher}
\fancyhead[R]{\small\sffamily Rev.\ 1.0 \;|\; 23 Nov 2026}\fancyfoot[R]{\small\sffamily\thepage}
\captionsetup{font=small,labelfont=bf}
\begin{document}
{\sffamily\bfseries\Large\color{brand} Proposed Technical Requirements Form -- Hypothetical European Micro-Launcher}\par\smallskip
{\small Companion to the report \emph{Comparative Engineering Analysis of European and International Micro-Launch Vehicles}. Values are preliminary targets for a conceptual design study; basis codes: D = derived from the comparative analysis, P = preliminary engineering target, A = assumption. Priority: Must / Should / Could. Table and chapter references point to the main report. An editable version is supplied as \texttt{requirements\_form.xlsx}.}\par
\smallskip
\begin{tabular}{@{}ll@{\qquad}ll@{}}
\toprule
Reference mission & 500 kg (Should) / 400 kg (Must) to 500 km SSO, 97.4\textdegree & Baseline sizing & %(m0).1f t GLOM at $I_\mathrm{sp}$ 305/340 s, $\varepsilon$ 0.10/0.14 (margin case) \\
Architecture & 2 stages + optional kick stage, LOX/hydrocarbon & Envelope & $\leq$ 2.2 m diameter, $\leq$ 30 m length \\
\bottomrule
\end{tabular}
\par\medskip
""" % dict(m0=BASE[3])
mt = matrix_tex(True).replace(r"\label{tab:req-matrix}", "")
mt = mt.replace(r"Table~\ref{tab:req-sens}", "report Table 22.1").replace(r"Table~\ref{tab:eps-summary}", "report Table 20.7")
std += mt + r"""
\vspace{4mm}
\begin{tabular}{@{}p{6cm}p{6cm}p{6cm}@{}}
\toprule
Prepared by: & Reviewed by: & Approved by: \\[8mm]
Date: & Date: & Date: \\
\bottomrule
\end{tabular}
\end{document}
"""
open(os.path.join(STD, "requirements_form.tex"), "w").write(std)

# XLSX (editable form + consolidated comparison)
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
wb = Workbook(); ws = wb.active; ws.title = "Requirements"
hdr = ["Requirement ID", "Category", "Requirement description", "Parameter", "Target value", "Unit", "Priority",
       "Rationale", "Basis (D/P/A)", "Verification method", "Status", "Owner", "Comments"]
ws.append(["Proposed Technical Requirements Form - Hypothetical European Micro-Launcher (Rev. 1.0, 23 Nov 2026)"])
ws.append(["Basis: D = derived from comparative analysis; P = preliminary engineering target; A = assumption. Verification: A analysis, T test, I inspection, D demonstration, R review."])
ws.append([]); ws.append(hdr)
thin = Side(style="thin", color="C3C2B7")
for c in range(1, len(hdr) + 1):
    cell = ws.cell(row=4, column=c); cell.font = Font(bold=True, color="FFFFFF")
    cell.fill = PatternFill("solid", fgColor="184F95"); cell.alignment = Alignment(wrap_text=True, vertical="center")
ws["A1"].font = Font(bold=True, size=13, color="184F95"); ws["A2"].font = Font(italic=True, size=9)
for r in R:
    ws.append([r["id"], CAT[r["id"].split("-")[0]], r["desc"], r["par"], r["tgt"], r["unit"], r["pri"], r["rat"], r["basis"], r["ver"], "Proposed", "", ""])
widths = [12, 22, 38, 30, 26, 9, 9, 70, 10, 14, 11, 12, 30]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[get_column_letter(i)].width = w
for row in ws.iter_rows(min_row=5, max_row=ws.max_row):
    for cell in row:
        cell.alignment = Alignment(wrap_text=True, vertical="top"); cell.border = Border(top=thin, bottom=thin, left=thin, right=thin)
ws.freeze_panes = "C5"
ws.auto_filter.ref = f"A4:{get_column_letter(len(hdr))}{ws.max_row}"
from openpyxl.worksheet.datavalidation import DataValidation
dv = DataValidation(type="list", formula1='"Must,Should,Could"', allow_blank=False)
ws.add_data_validation(dv); dv.add(f"G5:G{ws.max_row}")
dv2 = DataValidation(type="list", formula1='"Proposed,Agreed,Modified,Rejected,Verified"', allow_blank=True)
ws.add_data_validation(dv2); dv2.add(f"K5:K{ws.max_row}")

ws2 = wb.create_sheet("Sizing sensitivity")
ws2.append(["Isp S1 eff [s]", "Isp S2 vac [s]", "eps1", "eps2", "Payload fraction [%]", "GLOM for 500 kg [t]"])
for isp, eps, lam, m0 in cases:
    ws2.append([isp[0], isp[1], eps[0], eps[1], round(100 * lam, 3), round(m0, 2)])
for c in range(1, 7):
    ws2.cell(row=1, column=c).font = Font(bold=True); ws2.column_dimensions[get_column_letter(c)].width = 20
wb.save(os.path.join(STD, "requirements_form.xlsx"))

# Consolidated comparison as XLSX
wb2 = Workbook(); w = wb2.active; w.title = "Comparison"
with open(os.path.join(GEN, "consolidated_comparison.csv")) as f:
    rows = list(csv.reader(f))
w.append(["Consolidated technical comparison - data cut-off 23 Nov 2026 - see the full report for data classes and full citations"])
w["A1"].font = Font(bold=True, color="184F95")
for i, row in enumerate(rows):
    conv = []
    for x in row:
        try:
            conv.append(float(x) if ("." in x or x.isdigit()) else x)
        except ValueError:
            conv.append(x)
    w.append(conv)
for c in range(1, len(rows[0]) + 1):
    w.cell(row=2, column=c).font = Font(bold=True, color="FFFFFF"); w.cell(row=2, column=c).fill = PatternFill("solid", fgColor="184F95")
    w.cell(row=2, column=c).alignment = Alignment(wrap_text=True)
    w.column_dimensions[get_column_letter(c)].width = 18
w.freeze_panes = "B3"
wb2.save(os.path.join(STD, "consolidated_comparison.xlsx"))
print("requirements:", len(R), "baseline GLOM %.1f t, lambda %.2f %%" % (BASE[3], 100 * BASE[2]))

# --------------------------------------------------------------------------
# Condensed requirements table for the concise report
# --------------------------------------------------------------------------
cl = [r"\scriptsize", r"\renewcommand{\arraystretch}{1.08}", r"\setlength{\tabcolsep}{3.5pt}",
      r"\begin{longtable}{@{}>{\raggedright}p{1.15cm}>{\raggedright}p{5.2cm}>{\raggedright}p{6.0cm}>{\raggedright}p{1.1cm}>{\raggedright\arraybackslash}p{0.75cm}@{}}",
      r"\caption{Proposed requirements (condensed; full rationale and verification methods in the standalone form).}\label{tab:req-condensed}\\",
      r"\toprule ID & Requirement & Target value [unit] & Priority & Basis \\ \midrule \endfirsthead",
      r"\toprule ID & Requirement & Target value [unit] & Priority & Basis \\ \midrule \endhead",
      r"\bottomrule \endlastfoot"]
cur = None
for r in R:
    c = r["id"].split("-")[0]
    if c != cur:
        cl.append(r"\multicolumn{5}{@{}l}{\cellcolor{docbg}\textbf{%s}} \\" % CAT[c]); cur = c
    unit = "" if r["unit"] in ("--", "") else " " + esc(r["unit"])
    pri = {"Must": r"\textbf{Must}", "Should": "Should", "Could": r"\textit{Could}"}[r["pri"]]
    cl.append(r"%s & %s & %s%s & %s & %s \\" % (r["id"], esc(r["desc"]), esc(r["tgt"]), unit, pri, r["basis"]))
cl.append(r"\end{longtable}")
open(os.path.join(GEN, "req_condensed.tex"), "w").write("\n".join(cl) + "\n")
